// Reporte externo del Tablero de ruta.
// Funciona igual abierto desde la extensión (ícono) o publicado en GitHub Pages:
// en los dos casos le pide los datos a la extensión, que lee Nextbyn y Chess con tu sesión.
/* global chrome */
(function () {
  'use strict';

  var EXT_ID = 'fdamkbfagocimdchkjimcekiedpjldjm';
  var GUIA = '#guia';
  var CADA = 5 * 60 * 1000;
  var CLAVE_CFG = 'ldReporteCfg';
  var CLAVE_HIST = 'ldReporteHist';
  var CLAVE_DATOS = 'ldReporteDatos';
  var COLOR = { rojo: 'var(--rojo)', amarillo: 'var(--ambar)', verde: 'var(--verde)', azul: 'var(--azul)', gris: 'var(--gris)' };

  // ---------- utilidades ----------
  function $(id) { return document.getElementById(id); }
  function leerLS(k, def) { try { var v = localStorage.getItem(k); return v ? JSON.parse(v) : def; } catch (e) { return def; } }
  function guardarLS(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) { /* sin almacenamiento */ } }
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }
  function hhmm(d) { if (!d) return '—'; d = new Date(d); return ('0' + d.getHours()).slice(-2) + ':' + ('0' + d.getMinutes()).slice(-2); }
  function horas(h) { if (h == null) return '—'; var m = Math.round(60 * h); return Math.floor(m / 60) + 'h ' + ('0' + (m % 60)).slice(-2) + 'm'; }
  function plata(n) { return '$ ' + Math.round(n || 0).toLocaleString('es-AR'); }
  function num(n) { return Math.round(100 * (n || 0)) / 100; }
  function aHora(base, s) { var m = /^(\d{1,2}):(\d{2})$/.exec(s || '') || [0, 18, 0]; var d = new Date(base); d.setHours(+m[1], +m[2], 0, 0); return d; }
  function sabado(d) { return (d || new Date()).getDay() === 6; }
  function nz(s) { return String(s || '').toUpperCase().normalize('NFD').replace(/[^A-Z0-9]/g, ''); }
  function chapa(p) { return '<span class="chapa"><span>' + esc(p) + '</span></span>'; }

  // ---------- configuración ----------
  var CLAVE_AL = 'ldReporteAlertas', alAbierto = !!leerLS(CLAVE_AL, false); // panel de alertas: minimizado por defecto
  var cfg = Object.assign({ objLV: '15:00', objSab: '13:00', sinAvance: 45, demora: 10, cdLL: [-38.889468, -68.103915] }, leerLS(CLAVE_CFG, {}));
  if (!cfg.cdLL) cfg.cdLL = [-38.889468, -68.103915]; // CD Neuquén
  function objetivo(d) { return sabado(d) ? cfg.objSab : cfg.objLV; }
  function ventanaApertura(d) { return sabado(d) ? ['08:00', '08:30'] : ['07:30', '08:00']; }

  // ---------- día de entrega elegido (por defecto hoy; la elección dura hasta que cambia el día) ----------
  var CLAVE_DIA = 'ldReporteDia';
  var selDia = (function () { var x = leerLS(CLAVE_DIA, null); return x && x.en === fechaISO() && /^\d{4}-\d{2}-\d{2}$/.test(x.dia || '') ? x.dia : fechaISO(); })();
  function esHoy() { return selDia === fechaISO(); }
  function fechaDe(iso) { var p = iso.split('-'); return new Date(+p[0], +p[1] - 1, +p[2]); }
  // Hora de referencia para el análisis: ahora si es hoy; un día futuro, antes de empezar;
  // un día pasado, al final del día (muestra cómo terminó).
  function ahoraRef() {
    if (esHoy()) return new Date();
    var d = fechaDe(selDia);
    if (selDia > fechaISO()) { var ap = ventanaApertura(d)[0].split(':'); d.setHours(+ap[0], +ap[1], 0, 0); } // antes de salir
    else d.setHours(23, 59, 0, 0);
    return d;
  }

  // ---------- estado ----------
  var guardado = leerLS(CLAVE_DATOS, {});
  var hoy = new Date().toDateString();
  var nb = esHoy() && guardado.nb && new Date(guardado.nb.at).toDateString() === hoy ? guardado.nb : null; // { cams, cli, at }
  var ch = guardado.ch && new Date(guardado.ch.at).toDateString() === hoy && (guardado.ch.dia || fechaISO()) === selDia ? guardado.ch : null; // { data, at, dia }
  var errNb = '', errCh = '', errPr = '', sinExtension = false;
  var CLAVE_PRIO = 'ldReportePrio';
  var pr = leerLS(CLAVE_PRIO, null); // { mapa, at }
  var CLAVE_VENT = 'ldReporteVent', CLAVE_OBS = 'ldReporteObs';
  var vt = leerLS(CLAVE_VENT, null); // { v: 3, mapa: { codigo: { f: [[desde, hasta] en minutos], nota, pago, ll: [lat, lng] } }, at }
  if (vt && vt.v !== 6) vt = null; // caché anterior sin pago pendiente, ubicación o teléfono
  var errVt = '', leyendoVt = false;
  var abiertos = {}, clientesAbiertos = {};
  var ocupado = { nextbyn: false, chess: false };
  var proxima = 0, timer = null;

  // ---------- conexión con la extensión ----------
  function enExtension() { return location.protocol === 'chrome-extension:'; }
  // Versión de la extensión instalada (para avisar si quedó vieja respecto de la página).
  var VERSION_PAG = ((document.querySelector('.ver') || {}).textContent || '').replace(/^v/, '').trim(), extVersion = '';
  function consultarVersion() {
    try {
      var cb = function (r) { if (chrome.runtime.lastError || !r) return; extVersion = r.version || ''; pintar(); };
      if (enExtension()) extVersion = chrome.runtime.getManifest().version;
      else if (window.chrome && chrome.runtime && chrome.runtime.sendMessage) chrome.runtime.sendMessage(EXT_ID, { tipo: 'ping' }, cb);
    } catch (e) { /* sin extensión */ }
  }
  function pedir(tipo, extra) {
    var msg = Object.assign({ tipo: tipo }, extra || {});
    return new Promise(function (resolve, reject) {
      function cb(r) {
        var le = chrome.runtime && chrome.runtime.lastError;
        if (le || !r) return reject(new Error(le ? 'NOEXT' : 'La extensión no respondió.'));
        r.ok ? resolve(r.data) : reject(new Error(r.error));
      }
      try {
        if (enExtension()) chrome.runtime.sendMessage(msg, cb);
        else if (window.chrome && chrome.runtime && chrome.runtime.sendMessage) chrome.runtime.sendMessage(EXT_ID, msg, cb);
        else reject(new Error('NOEXT'));
      } catch (e) { reject(new Error('NOEXT')); }
    });
  }

  // ---------- app de choferes: reemplaza a Nextbyn como fuente de entregas ----------
  var nbNextbyn = nb && nb.fuente !== 'app' ? nb : null; // última lectura real de Nextbyn (para el orden de visita)
  function modoApp() { return !!(window.LTChoferes && LTChoferes.modoApp()); }
  function datosApp() {
    var d = LTChoferes.datosNb();
    if (d) { nb = d; errNb = ''; registrarObservaciones(); }
  }
  if (window.LTChoferes) {
    if (LTChoferes.ponerDia) LTChoferes.ponerDia(selDia);
    LTChoferes.alCambiar = function (cambioFuente) {
      if (modoApp()) datosApp();
      else if (cambioFuente) { nb = esHoy() ? nbNextbyn : null; if (!nb) actualizar('nextbyn'); }
      pintar();
    };
    LTChoferes.alGps = function () { if (window.LTMapa) LTMapa.refrescarGps(); };
  }

  function actualizar(tipo) {
    if (tipo === 'nextbyn' && modoApp()) { datosApp(); pintar(); return Promise.resolve(); }
    // Nextbyn solo muestra el día en curso.
    if (tipo === 'nextbyn' && !esHoy()) { nb = null; errNb = 'Nextbyn solo tiene las entregas de hoy. Para otro día usá la app de choferes como fuente (pestaña App choferes).'; pintar(); return Promise.resolve(); }
    if (ocupado[tipo]) return Promise.resolve();
    ocupado[tipo] = true;
    pintarBotones();
    var diaPedido = selDia;
    return pedir(tipo, tipo === 'chess' ? { fecha: diaPedido } : null).then(function (data) {
      sinExtension = false;
      if (diaPedido !== selDia) return; // mientras leía, se eligió otro día
      if (tipo === 'nextbyn') { nb = data; nbNextbyn = data; errNb = ''; registrarObservaciones(); } else { data.dia = diaPedido; ch = data; errCh = ''; }
      guardarLS(CLAVE_DATOS, { nb: esHoy() ? nb : nbNextbyn, ch: ch });
    }, function (e) {
      var m = String(e.message || e);
      if (m === 'NOEXT') { sinExtension = true; m = 'Falta la extensión'; }
      if (diaPedido !== selDia) return;
      if (tipo === 'nextbyn') errNb = m; else errCh = m;
    }).then(function () {
      ocupado[tipo] = false; pintar(); quizasGuardar();
      if (diaPedido !== selDia) return actualizar(tipo);
      if (tipo === 'chess' && !errCh) { quizasActualizarBase(); if (window.LTChoferes) LTChoferes.alLeerChess(ch, vt, nbNextbyn); }
    });
  }

  // ---------- base de clientes: una vez por día, de Chess a la hoja de clientes ----------
  var CLAVE_BASE = 'ldReporteBase';
  var base = leerLS(CLAVE_BASE, {}); // { dia, at, clientes, err, intento }
  var baseOcupada = false;
  function quizasActualizarBase() {
    var ahora = new Date();
    if (!hcfg.url || baseOcupada || base.dia === fechaISO(ahora) || ahora.getHours() < 6) return;
    if (base.intento && Date.now() - base.intento < 30 * 6e4) return; // después de un error, reintenta cada 30 min
    actualizarBase(false);
  }
  function actualizarBase(forzar) {
    if (baseOcupada) return;
    if (!hcfg.url) { base.err = 'Primero configurá el script de la hoja en la pestaña Histórico (paso 2).'; pintarBase(); location.hash = '#historico'; return; }
    baseOcupada = true; pintarBase();
    pedir('baseClientes', { url: hcfg.url, forzar: !!forzar }).then(function (d) {
      base = { dia: fechaISO(), at: d.at || Date.now(), clientes: d.clientes, horarios: d.horarios, cadenas: d.cadenas, yaEstaba: !!d.yaEstaba };
      guardarLS(CLAVE_BASE, base);
      if (!d.yaEstaba || !vt || vt.at < base.at) actualizarVentanas(true);
    }, function (e) {
      var m = String(e.message || e);
      base.err = m === 'NOEXT' ? 'Falta la extensión.' : m;
      base.intento = Date.now();
      guardarLS(CLAVE_BASE, base);
    }).then(function () { baseOcupada = false; pintarBase(); });
  }
  function pintarBase() {
    var b = $('b-base');
    if (!b) return;
    var hoyB = base.dia === fechaISO();
    var txt = baseOcupada ? 'actualizando…' : hoyB ? 'hoy ' + hhmm(base.at) : base.err ? 'sin actualizar' : base.at ? 'del ' + new Date(base.at).toLocaleDateString('es-AR', { day: 'numeric', month: 'numeric' }) : 'sin actualizar';
    b.querySelector('.base-est').textContent = txt;
    b.className = 'base-btn' + (baseOcupada ? ' ocupada' : hoyB ? ' ok' : base.err ? ' err' : '');
    b.disabled = baseOcupada;
    b.title = baseOcupada ? 'Bajando la base de clientes de Chess y guardándola en la hoja…'
      : (hoyB ? 'Base de clientes actualizada hoy a las ' + hhmm(base.at) + (base.clientes ? ' (' + base.clientes + ' clientes)' : '') + '. '
        : base.err ? 'No se pudo actualizar: ' + base.err + ' ' : 'La base de clientes se actualiza sola una vez por día al leer Chess. ')
      + 'Tocá para bajarla de Chess ahora.';
  }

  function actualizarTodo() {
    programar();
    // La hoja de prioridades cambia poco: se vuelve a leer si tiene más de 1 hora.
    if (!pr || Date.now() - pr.at > 36e5) actualizarPrioridades();
    if (!vt || !vt.conTel || Date.now() - vt.at > 36e5) actualizarVentanas();
    return Promise.all([actualizar('nextbyn'), actualizar('chess')]);
  }

  function actualizarVentanas() {
    if (leyendoVt) return;
    leyendoVt = true;
    pedir('ventanas').then(function (data) {
      var mv = armarVentanas(data.csv);
      vt = { v: 6, mapa: mv, at: data.at, conTel: !!mv.__conTel };
      delete mv.__conTel;
      errVt = '';
      guardarLS(CLAVE_VENT, vt);
      // La hoja de ruta de la app lleva ubicación, ventana y teléfono de esta hoja: se vuelve a publicar.
      if (ch && window.LTChoferes) LTChoferes.alLeerChess(ch, vt, nbNextbyn);
    }).catch(function (e) {
      var m = String(e.message || e);
      errVt = m === 'NOEXT' ? 'falta la extensión' : m;
    }).then(function () { leyendoVt = false; pintar(); });
  }

  var leyendoPr = false;
  function actualizarPrioridades() {
    if (leyendoPr) return;
    leyendoPr = true;
    pedir('prioridades').then(function (data) {
      pr = { mapa: armarPrioridades(data.csv), at: data.at };
      errPr = '';
      guardarLS(CLAVE_PRIO, pr);
    }).catch(function (e) {
      var m = String(e.message || e);
      errPr = m === 'NOEXT' ? 'falta la extensión' : m;
    }).then(function () { leyendoPr = false; refrescarPopover(); });
  }

  function programar() {
    clearTimeout(timer);
    proxima = 0;
    if (!$('auto').checked) return;
    proxima = Date.now() + CADA;
    timer = setTimeout(actualizarTodo, CADA);
  }

  // ---------- análisis (semáforo) ----------
  function analizar(cams, ahora) {
    var hist = leerLS(CLAVE_HIST, {});
    var fin = aHora(ahora, objetivo(ahora));
    var res = cams.map(function (c) {
      var e = Object.assign({}, c);
      e.alertas = []; e.aviso = ''; e.tarde = 0;
      try { e.plan = planRuta(e, ahora); } catch (x) { e.plan = null; }
      var ini = e.inicio ? new Date(e.inicio) : null;
      if (ini && ini.getHours() >= 4) {
        var v = ventanaApertura(ini), v0 = aHora(ini, v[0]), v1 = aHora(ini, v[1]);
        if (ini > v1) { e.tarde = Math.round((ini - v1) / 6e4); e.aviso = 'Levantó ruta tarde: ' + hhmm(ini) + ' (' + e.tarde + ' min después de las ' + v[1] + ')'; }
        else if (ini < v0 - 15 * 6e4) e.aviso = 'Levantó ruta antes de horario: ' + hhmm(ini) + ' (ventana ' + v[0] + ' a ' + v[1] + ')';
      }
      var h = ini ? (ahora - ini) / 36e5 : null;
      e.horas = h;
      e.ritmo = h && h > 0.05 ? e.hechos / h : null;
      e.fin = null;
      var o = hist[e.patente];
      if (!(o && o.hechos === e.hechos && o.dia === ahora.toDateString())) o = { hechos: e.hechos, desde: ahora.getTime(), dia: ahora.toDateString() };
      hist[e.patente] = o;
      e.sinAvanceMin = (ahora - o.desde) / 6e4;
      if (e.estado === 'CERRADA') {
        if (e.pendientes > 0) { e.sem = 'rojo'; e.txt = 'Cerró con ' + e.pendientes + ' pendientes'; e.alertas.push('Cerró la jornada con ' + e.pendientes + ' clientes pendientes'); }
        else { e.sem = 'gris'; e.txt = 'Finalizado'; }
      } else if (e.pendientes === 0) { e.sem = 'verde'; e.txt = 'Sin pendientes, falta cerrar'; }
      else if (ini && ini.getHours() < 4) { e.sem = 'amarillo'; e.txt = 'Inicio anómalo'; e.ritmo = null; e.alertas.push('Jornada iniciada a las ' + hhmm(ini) + ': revisar si quedó abierta de antes'); }
      else if (!ini) { e.sem = 'azul'; e.txt = e.estado === 'SIN INICIAR' ? 'Sin iniciar en la app' : 'Sin inicio de jornada'; }
      else if (h !== null && h < 0.75) { e.sem = 'azul'; e.txt = 'Recién sale'; }
      else if (e.ritmo) {
        e.fin = new Date(ahora.getTime() + (e.pendientes / e.ritmo) * 36e5);
        var dif = (e.fin - fin) / 6e4;
        if (dif <= 0) { e.sem = 'verde'; e.txt = 'En horario'; }
        else if (dif <= 60) { e.sem = 'amarillo'; e.txt = 'Ajustado'; }
        else { e.sem = 'rojo'; e.txt = 'Demorado'; }
      } else { e.sem = 'rojo'; e.txt = 'Sin entregas'; e.alertas.push('Lleva ' + horas(h) + ' de jornada sin visitas registradas'); }
      if (e.estado === 'ABIERTA' && e.pendientes > 0 && e.sinAvanceMin >= cfg.sinAvance) e.alertas.push('Sin nuevas visitas hace ' + Math.round(e.sinAvanceMin) + ' min');
      if (e.rechazos > 0) e.alertas.push(e.rechazos + (e.rechazos === 1 ? ' rechazo' : ' rechazos'));
      e.orden = 1000 * { rojo: 0, amarillo: 1, azul: 2, verde: 3, gris: 4 }[e.sem] - 10 * e.alertas.length + (e.ritmo || 0);
      return e;
    });
    guardarLS(CLAVE_HIST, hist);
    return res.sort(function (a, b) { return a.orden - b.orden; });
  }

  // ---------- escala de la línea del día ----------
  function escala(cams, ahora) {
    var desde = 6, hasta = Math.max(aHora(ahora, objetivo(ahora)).getHours() + 2, ahora.getHours() + 1);
    cams.forEach(function (e) {
      var i = e.inicio && new Date(e.inicio);
      if (i && i.getHours() >= 4) desde = Math.min(desde, i.getHours());
      if (e.fin && e.fin.toDateString() === ahora.toDateString()) hasta = Math.max(hasta, Math.ceil(e.fin.getHours() + e.fin.getMinutes() / 60));
      if (e.plan && e.plan.fin.toDateString() === ahora.toDateString()) hasta = Math.max(hasta, Math.ceil(e.plan.fin.getHours() + e.plan.fin.getMinutes() / 60));
    });
    hasta = Math.min(Math.max(hasta, desde + 6), 22);
    var a = aHora(ahora, ('0' + desde).slice(-2) + ':00').getTime();
    var b = aHora(ahora, ('0' + hasta).slice(-2) + ':00').getTime();
    return {
      desde: desde, hasta: hasta,
      x: function (t) { t = +new Date(t); return Math.max(0, Math.min(100, ((t - a) / (b - a)) * 100)); },
      fuera: function (t) { return +new Date(t) > b; },
    };
  }

  // ---------- horario proyectado de la ruta ----------
  // Desde el inicio de ruta (o la apertura, si todavía no salió): viaje del CD al primer cliente, entre
  // clientes en el orden de la hoja de ruta y de vuelta al CD, en línea recta × 1,3 (calles) a 25 km/h,
  // más la demora por cliente.
  var VEL_KMH = 25, FACTOR_CALLES = 1.3;
  function kmEntre(a, b) {
    var r = Math.PI / 180, dLa = (b[0] - a[0]) * r, dLo = (b[1] - a[1]) * r;
    var x = Math.sin(dLa / 2) * Math.sin(dLa / 2) + Math.cos(a[0] * r) * Math.cos(b[0] * r) * Math.sin(dLo / 2) * Math.sin(dLo / 2);
    return 2 * 6371 * Math.asin(Math.sqrt(x)) * FACTOR_CALLES;
  }
  function planRuta(e, ahora) {
    var pat = String(e.patente).toUpperCase(), lista = listaClientes(pat);
    if (!lista.length) return null;
    var orden = lista.map(function (c, i) { return { c: c, k: c.n != null ? c.n : c.seq != null ? c.seq : 1e4 + i, i: i }; })
      .sort(function (a, b) { return a.k - b.k || a.i - b.i; }).map(function (x) { return x.c; });
    var ini = e.inicio ? new Date(e.inicio) : null;
    if (!ini || ini.getHours() < 4) ini = aHora(ahora, ventanaApertura(ahora)[0]);
    var km = 0, sinLl = 0, prev = cfg.cdLL, n = 0, demTot = 0, fuentes = { manual: 0, historial: 0, general: 0 };
    orden.forEach(function (c) {
      var v = vt && vt.mapa && c.codigo ? vt.mapa[c.codigo] : null;
      if (v && v.ll) { if (prev) km += kmEntre(prev, v.ll); prev = v.ll; } else sinLl++;
      var d = demoraPlan(c.codigo);
      demTot += d.min; fuentes[d.fuente]++;
      n++;
    });
    if (cfg.cdLL && prev && prev !== cfg.cdLL) km += kmEntre(prev, cfg.cdLL);
    var manejo = km / VEL_KMH * 60, total = manejo + demTot;
    return { ini: ini, fin: new Date(ini.getTime() + total * 6e4), km: km, manejo: manejo, n: n, sinLl: sinLl, conCD: !!cfg.cdLL, demTot: demTot, fuentes: fuentes };
  }
  function textoPlan(p) {
    var f = p.fuentes, det = [];
    if (f.historial) det.push(f.historial + ' según su historial de check-in');
    if (f.manual) det.push(f.manual + ' con demora fijada a mano');
    if (f.general) det.push(f.general + ' con la general de ' + cfg.demora + ' min');
    return 'Horario proyectado: sale ' + hhmm(p.ini) + ', termina ~' + hhmm(p.fin) + ' (' + p.n + ' clientes con ' + Math.round(p.demTot) + ' min de demora: ' + det.join(', ') + '; + ' +
      Math.round(p.km) + ' km a ' + VEL_KMH + ' km/h = ' + Math.round(p.manejo) + ' min de manejo' + (p.conCD ? ', con ida y vuelta al CD' : ', sin el viaje desde y hacia el CD') + ')' +
      (p.sinLl ? '. ' + p.sinLl + ' clientes sin ubicación: solo suman la demora.' : '.');
  }

  function lineaDelDia(e, E, ahora) {
    var v = ventanaApertura(ahora), obj = aHora(ahora, objetivo(ahora));
    var c = '<div class="dia" title="' + esc(lineaTitulo(e)) + '"><div class="carril"></div>' +
      '<div class="ventana" style="left:' + E.x(aHora(ahora, v[0])) + '%;width:' + (E.x(aHora(ahora, v[1])) - E.x(aHora(ahora, v[0]))) + '%"></div>';
    var ini = e.inicio ? new Date(e.inicio) : null;
    var xi = ini && ini.getHours() >= 4 ? E.x(ini) : 0;
    var xa = E.x(ahora);
    if (ini) {
      c += '<div class="hecho" style="left:' + xi + '%;width:' + Math.max(0, xa - xi) + '%' + (e.estado === 'CERRADA' ? ';opacity:.35' : '') + '"></div>';
      if (ini.getHours() >= 4) c += '<div class="ini" style="left:' + xi + '%"></div>';
    }
    if (e.fin) {
      var fuera = E.fuera(e.fin), xf = fuera ? 100 : E.x(e.fin);
      c += '<div class="proy" style="left:' + xa + '%;width:' + Math.max(0, xf - xa) + '%"></div>';
      c += '<div class="fin' + (fuera ? ' fuera' : '') + '" style="left:' + xf + '%"></div>';
    }
    if (e.plan) {
      var pf = E.fuera(e.plan.fin), xpi = E.x(e.plan.ini), xpf = pf ? 100 : E.x(e.plan.fin);
      c += '<div class="plan' + (e.plan.fin > obj ? ' tarde' : '') + '" style="left:' + xpi + '%;width:' + Math.max(0.5, xpf - xpi) + '%" title="' + esc(textoPlan(e.plan)) + '"></div>' +
        '<div class="plan-fin' + (e.plan.fin > obj ? ' tarde' : '') + '" style="left:' + xpf + '%" title="' + esc(textoPlan(e.plan)) + '"><span>' + hhmm(e.plan.fin) + '</span></div>';
    }
    c += '<div class="obj" style="left:' + E.x(obj) + '%"></div><div class="ahora" style="left:' + xa + '%"></div></div>';
    return c;
  }
  function lineaTitulo(e) {
    var t = 'Inicio ' + hhmm(e.inicio);
    if (e.fin) t += ', fin estimado ' + hhmm(e.fin);
    if (e.plan) t += '. ' + textoPlan(e.plan);
    return t;
  }

  function eje(E, ahora) {
    var h = '<div class="reloj">';
    var paso = E.hasta - E.desde > 10 ? 2 : 1;
    for (var x = E.desde; x <= E.hasta; x += paso) {
      h += '<span style="left:' + ((x - E.desde) / (E.hasta - E.desde)) * 100 + '%">' + ('0' + x).slice(-2) + ':00</span>';
    }
    var obj = aHora(ahora, objetivo(ahora));
    h += '<span class="tag o" style="left:' + E.x(obj) + '%">Fin ' + objetivo(ahora) + '</span>';
    h += '<span class="tag a" style="left:' + E.x(ahora) + '%">' + hhmm(ahora) + '</span>';
    return h + '</div>';
  }

  // ---------- clientes de un camión ----------
  function estadoNextbyn(s) {
    if (/RECHAZO.*PARCIAL|PARCIAL/.test(s)) return 'parcial';
    if (/^RECHAZ/.test(s)) return 'rechazado'; // RECHAZO (Nextbyn) o RECHAZADO (app de choferes)
    if (/^ENTREGA/.test(s)) return 'entregado';
    return '';
  }
  // Rechazos cargados por estos usuarios en Chess son devoluciones.
  var USUARIOS_DEVOLUCION = ['CGORDONES'];
  function esDevolucion(it) { return !!(it && it.rechazado && it.usuario && USUARIOS_DEVOLUCION.indexOf(it.usuario) >= 0); }
  function clienteDevolucion(c) {
    var r = (c.items || []).filter(function (it) { return it.rechazado; });
    return r.length > 0 && r.every(esDevolucion);
  }
  function pillEstado(c) {
    var dev = clienteDevolucion(c);
    if (c.est === 'rechazado') return '<span class="pill p-re">' + (c.noEntApp ? 'No entregado' : dev ? 'Devolución' : 'Rechazado') + '</span>';
    if (c.est === 'parcial') return '<span class="pill p-re">' + (dev ? 'Devolución parcial' : 'Rechazo parcial') + '</span>';
    if (c.est === 'entregado') return '<span class="pill p-ok">Entregado</span>';
    if (c.nc) return '<span class="pill p-nc" title="' + esc('Visita no concretada: ' + c.nc.motivo + (c.nc.nota ? ' (' + c.nc.nota + ')' : '') + ' a las ' + hhmm(c.nc.t)) + '">' +
      (c.nc.estado === 'revisita' ? 'Re-visita confirmada' : c.nc.estado === 'norevisitar' ? 'No re-visitar' : 'No concretada') + '</span><span class="motivo">' + esc(c.nc.motivo) + (c.nc.nota ? ': ' + esc(c.nc.nota) : '') + '</span>';
    if (c.nbEstado) return '<span class="pill p-pe">' + esc(c.nbEstado.replace(/_/g, ' ').toLowerCase().replace(/^./, function (x) { return x.toUpperCase(); })) + '</span>';
    return '<span class="pill p-pe">' + (c.leidoNextbyn ? 'Pendiente' : 'En reparto') + '</span>';
  }
  function orden(c) { return { rechazado: 0, parcial: 0, '': 1, entregado: 2 }[c.est || '']; }

  // Cruza cada cliente de Chess con su estado en Nextbyn (por código, o por nombre).
  function cruzar(dc, nbCli) {
    var porNombre = {};
    Object.keys(nbCli).forEach(function (k) { porNombre[nz(nbCli[k].nombre)] = nbCli[k]; });
    return dc.clientes.map(function (c0) {
      var c = Object.assign({}, c0);
      c.codigo = (/^\s*(\d+)/.exec(c.cliente) || [])[1] || '';
      var x = (c.codigo && nbCli[c.codigo]) || porNombre[nz(String(c.cliente).replace(/^\s*\d+\s*-\s*/, ''))];
      c.leidoNextbyn = !!x;
      c.nbEstado = x ? x.estado : '';
      if (x && x.motivo) c.motivos = (c.motivos || []).concat(['App: ' + x.motivo]);
      c.noEntApp = !!(x && x.fuente === 'app' && /^RECHAZ/.test(x.estado) && !c.rechazado);
      c.horaNb = x && x.hora ? x.hora : null;
      c.seq = x && x.seq != null ? x.seq : null;
      c.optPos = x && x.optPos ? x.optPos : null;
      c.n = x && x.n != null ? x.n : null;
      c.demora = x && x.demora != null ? x.demora : null;
      c.enCliente = x && x.enCliente ? x.enCliente : null;
      c.nc = x && x.nc ? x.nc : null;
      c.est = c.rechazado ? 'rechazado' : c.parcial ? 'parcial' : c.entregado ? 'entregado' : '';
      var s = x && estadoNextbyn(x.estado);
      if (s === 'rechazado' || s === 'parcial') c.est = s;
      else if (s === 'entregado' && !c.est) c.est = 'entregado';
      // Sin dato de Nextbyn: estado de la liquidación de Chess (ENTREGADO, ENTREGA PARCIAL, NO VISITADO).
      if (!s && !c.est && c.estadoLiq) {
        if (/RECHAZ/.test(c.estadoLiq)) c.est = 'rechazado';
        else if (/ENTREGA/.test(c.estadoLiq)) c.est = 'entregado';
      }
      return c;
    });
  }

  // ---------- prioridad de pedidos pendientes (hoja PL4.2 Carga ruteo) ----------
  var NOMBRE_PRIO = { 1: 'Ganador', 2: 'Básico', 3: 'En crecimiento', 4: 'Ventas bajas' };
  function leerCSV(texto) {
    var filas = [], fila = [], campo = '', comillas = false;
    for (var i = 0; i < texto.length; i++) {
      var c = texto[i];
      if (comillas) {
        if (c === '"') { if (texto[i + 1] === '"') { campo += '"'; i++; } else comillas = false; }
        else campo += c;
      } else if (c === '"') comillas = true;
      else if (c === ',') { fila.push(campo); campo = ''; }
      else if (c === '\n' || c === '\r') {
        if (c === '\r' && texto[i + 1] === '\n') i++;
        fila.push(campo); filas.push(fila); fila = []; campo = '';
      } else campo += c;
    }
    if (campo || fila.length) { fila.push(campo); filas.push(fila); }
    return filas;
  }
  // Devuelve { codigo: { p, cluster, ventana, espera } } o lanza un error si no encuentra las columnas.
  // Ojo: Google, al exportar, deja vacío el título de las columnas numéricas (Cod. Cliente y las
  // prioridades), así que esas columnas se ubican por su posición junto a las que sí tienen título.
  function armarPrioridades(csv) {
    var filas = leerCSV(csv), h = -1;
    var norm = function (x) { return String(x || '').normalize('NFC').replace(/\s+/g, ' ').trim().toLowerCase(); };
    for (var i = 0; i < Math.min(filas.length, 40); i++) {
      var t = filas[i].map(norm).join('|');
      if (/(^|\|)nombre(\||$)/.test(t) && /cl[uú]ster vigente/.test(t)) { h = i; break; }
    }
    if (h < 0) throw new Error('No encontré las columnas «Nombre» y «Clúster vigente» en la pestaña PL4.2 Carga ruteo.');
    var cab = filas[h].map(norm);
    function col(re) { for (var k = 0; k < cab.length; k++) if (re.test(cab[k])) return k; return -1; }
    var cNom = col(/^nombre$/), cClu = col(/cl[uú]ster vigente/), cC1 = col(/cl[uú]ster corrida 1/);
    var cCod = col(/cod\.?\s*cliente/);
    if (cCod < 0) cCod = cNom - 1;
    var cPrio = col(/prioridad.*ruteo/);
    if (cPrio < 0 && cC1 >= 0) cPrio = cC1 + 2; // Prioridad stock, Prioridad en el ruteo
    var cVen = col(/ventana/), cEsp = col(/espera/);
    if (cEsp < 0) { var cRe = col(/reintento/); if (cRe >= 0) cEsp = cRe + 1; }
    var porCluster = { ganador: 1, 'básico': 2, basico: 2, 'en crecimiento': 3, 'ventas bajas': 4 };
    var mapa = {}, n = 0;
    for (var j = h + 1; j < filas.length; j++) {
      var f = filas[j], cod = String(f[cCod] || '').trim().replace(/\.0+$/, '');
      if (!/^\d+$/.test(cod)) continue;
      var clu = String(f[cClu] || '').trim();
      var desdeCluster = porCluster[norm(clu)] || 0;
      var p = cPrio >= 0 ? parseInt(f[cPrio], 10) : NaN;
      // Si la columna de prioridad no es la esperada, manda el clúster (la prioridad sale de él).
      if (!(p >= 1 && p <= 4) || (desdeCluster && p !== desdeCluster)) p = desdeCluster;
      var esp = cEsp >= 0 ? String(f[cEsp] || '').trim().replace(/\.0+$/, '') : '';
      mapa[cod] = { p: p, cluster: clu, ventana: cVen >= 0 ? String(f[cVen] || '').trim() : '', espera: /^\d+$/.test(esp) ? esp : '' };
      n++;
    }
    if (!n) throw new Error('La pestaña PL4.2 Carga ruteo no tiene clientes con código.');
    return mapa;
  }

  // Pendientes de un camión, ordenados: prioridad del ruteo (1 primero), después mayor importe.
  function pendientesDe(pat) {
    var nbCli = (nb && nb.cli && nb.cli.p && nb.cli.p[pat]) || {};
    var dc = ch && ch.data && ch.data[pat];
    var lista;
    if (dc) lista = cruzar(dc, nbCli);
    else lista = Object.keys(nbCli).map(function (id) {
      var x = nbCli[id];
      return { codigo: id.indexOf('N:') ? id : '', cliente: (id.indexOf('N:') ? id + ' - ' : '') + x.nombre, domicilio: x.domicilio, est: estadoNextbyn(x.estado), leidoNextbyn: true };
    });
    var mapa = (pr && pr.mapa) || {};
    var pend = lista.filter(function (c) { return !c.est; }).map(function (c) {
      var x = mapa[c.codigo] || null;
      return Object.assign({}, c, { prio: x && x.p ? x.p : 9, plan: x });
    });
    pend.sort(function (a, b) { return a.prio - b.prio || (b.importe || 0) - (a.importe || 0) || String(a.cliente).localeCompare(b.cliente); });
    return { lista: pend, fuente: dc ? 'chess' : lista.length ? 'nextbyn' : '', confirmados: !!(nb && nb.cli && nb.cli.n) };
  }

  // Cantidad para el botón: la lista real de pendientes si ya hay detalle de clientes; si no, el contador de Nextbyn.
  function cantidadPendientes(e) {
    var r = pendientesDe(String(e.patente).toUpperCase());
    return r.fuente ? r.lista.length : e.pendientes;
  }

  function vistaPrioridad(pat) {
    var r = pendientesDe(pat);
    var h = '<div class="pp-cab"><b>Pedidos pendientes de ' + esc(pat) + '</b><span>Orden de visita sugerido por prioridad del ruteo; dentro de cada prioridad, primero el de mayor importe.</span></div>';
    if (!pr) h += '<p class="pp-msg">' + (errPr ? 'No se pudo leer la hoja de prioridades: ' + esc(errPr) : 'Leyendo la hoja de prioridades…') + '</p>';
    if (!r.fuente) return h + '<p class="pp-msg">Todavía no hay detalle de clientes de este camión. Tocá <b>Actualizar todo</b>.</p>';
    if (!r.lista.length) return h + '<p class="pp-msg">No quedan pedidos pendientes.</p>';
    if (r.fuente === 'chess' && !r.confirmados) h += '<p class="pp-msg">Sin estados de Nextbyn: puede incluir clientes ya entregados.</p>';
    h += '<ol class="pp-lista">' + r.lista.map(function (c) {
      var plan = c.plan;
      var nombre = String(c.cliente).replace(/^\s*\d+\s*-\s*/, '');
      return '<li class="p' + c.prio + '"><span class="pp-cli"><b>' + esc(nombre) + '</b><small>' + esc(c.codigo || '') + (c.domicilio ? ', ' + esc(c.domicilio) : '') + '</small></span>' +
        '<span class="pp-plan">' + (plan && plan.p ? '<span class="pp-tag">P' + plan.p + ' ' + esc(plan.cluster || NOMBRE_PRIO[plan.p] || '') + '</span><small>' + esc([plan.ventana, plan.espera ? 'espera máx. ' + plan.espera + ' min' : ''].filter(Boolean).join(', ')) + '</small>' : '<span class="pp-tag sin">' + (plan ? 'Sin prioridad (' + esc(plan.cluster || 'sin clúster') + ')' : 'Sin prioridad en la hoja') + '</span>') + '</span>' +
        (c.importe != null ? '<span class="pp-imp">' + plata(c.importe) + '</span>' : '') + '</li>';
    }).join('') + '</ol>';
    if (pr) h += '<p class="pp-pie">Hoja PL4.2 Carga ruteo leída a las ' + hhmm(pr.at) + '.</p>';
    return h;
  }

  // ---------- OT: entregas dentro de la ventana horaria ----------
  // Hoja de clientes (select D, F, BO, W, CA, T, U): código, razón social, "hh:mm a hh:mm; hh:mm a hh:mm",
  // comentario, descripción de sub-línea, longitud y latitud. Pago pendiente autorizado: comentario
  // con "AUTORIZADO" (no "NO AUTORIZADO") o cliente en cuenta corriente.
  // Teléfonos del cliente (columnas N "Teléfono Móvil" y M "Teléfonos"): [{ n: para marcar, t: como figura, movil }].
  // Números de 10 dígitos (característica + número): móvil → +54 9…, fijo → +54…. Otros, tal cual.
  function telefonos(movil, fijos) {
    var out = [], vistos = {};
    function agregar(txt, esMovil) {
      var s0 = String(txt == null ? '' : txt).trim();
      // Google puede mandar la columna como número: 2996540478, 2.996540478E9 o con separadores de miles.
      if (/^\d+(\.\d+)?e\+?\d+$/i.test(s0)) s0 = Number(s0).toFixed(0);
      else if (/^[\d.,\s]+$/.test(s0) && s0.replace(/\D/g, '').length >= 8 && !/\d\s{2,}\d/.test(s0)) s0 = s0.replace(/\D/g, '');
      s0.split(/[\/;,]| - |\s{2,}/).forEach(function (p) {
        var d = p.replace(/\D/g, '');
        if (d.length < 6) return;
        d = d.replace(/^54/, '').replace(/^0/, '');
        if (d.length === 12 && /^\d{2,4}15/.test(d)) { var m = /^(\d{2,4})15(\d+)$/.exec(d); if (m && (m[1] + m[2]).length === 10) { d = m[1] + m[2]; esMovil = true; } }
        if (d.length === 11 && d[0] === '9') { d = d.slice(1); esMovil = true; }
        if (vistos[d]) return;
        vistos[d] = 1;
        out.push({ n: d.length === 10 ? (esMovil ? '+549' : '+54') + d : d, t: d, movil: !!esMovil });
      });
    }
    agregar(movil, true);
    agregar(fijos, false);
    return out.slice(0, 3);
  }
  function armarVentanas(csv) {
    var filas = leerCSV(csv), mapa = {}, n = 0;
    filas.forEach(function (f) {
      var cod = String(f[0] || '').trim().replace(/\.0+$/, '');
      if (!/^\d+$/.test(cod)) return;
      var txt = String(f[2] || '').trim(), fr = [], re = /(\d{2}):(\d{2}) a (\d{2}):(\d{2})/g, m;
      while ((m = re.exec(txt))) fr.push([+m[1] * 60 + +m[2], +m[3] * 60 + +m[4]]);
      var limpio = /^\d{2}:\d{2} a \d{2}:\d{2}(; \d{2}:\d{2} a \d{2}:\d{2})*$/.test(txt);
      mapa[cod] = { f: limpio ? fr : [], nota: !limpio && txt ? txt : '', pago: pagoAutorizado(f[3], f[4]), ll: ubicacion(f[6], f[5]), tel: telefonos(f[8], f[7]) };
      n++;
    });
    if (!n) throw new Error('La hoja de ventanas horarias no tiene clientes con código.');
    // Las columnas de teléfono (M y N) llegan solo si la extensión está actualizada (1.5.0 o más).
    mapa.__conTel = filas.some(function (f) { return f.length >= 9; });
    return mapa;
  }
  // Latitud y longitud del cliente (Argentina: ambas negativas). Sin dato o en 0: null.
  function ubicacion(lat, lng) {
    var a = parseFloat(String(lat || '').replace(',', '.')), b = parseFloat(String(lng || '').replace(',', '.'));
    if (!isFinite(a) || !isFinite(b) || !a || !b) return null;
    a = -Math.abs(a); b = -Math.abs(b);
    if (a < -56 || a > -21 || b < -74 || b > -53) return null;
    return [Math.round(a * 1e6) / 1e6, Math.round(b * 1e6) / 1e6];
  }
  function pagoAutorizado(comentario, subLinea) {
    var com = String(comentario || '').toUpperCase(), sub = String(subLinea || '').toUpperCase().trim();
    if (/\bAUTORIZADO\b/.test(com) && !/\bNO\s+AUTORIZADO\b/.test(com)) return 'com';
    if (sub === 'CUENTA CORRIENTE') return 'cc';
    if (sub === 'AUTORIZADO') return 'com';
    return '';
  }
  // Columna "Pago pendiente" de la lista de clientes.
  function pillPago(c) {
    if (!vt) return '<span class="tenue">—</span>';
    var v = c.codigo ? vt.mapa[c.codigo] : null;
    if (!v) return '<span class="pill p-pe" title="El cliente no está en la hoja de clientes">Sin dato</span>';
    if (v.pago === 'cc') return '<span class="pill p-ok" title="Cliente en cuenta corriente">Autorizado</span><span class="pago-por">Cta. corriente</span>';
    if (v.pago) return '<span class="pill p-ok" title="Comentario de la hoja de clientes: AUTORIZADO">Autorizado</span>';
    return '<span class="pill p-na">No autorizado</span>';
  }
  function minDelDia(t) { var d = new Date(t); return d.getHours() * 60 + d.getMinutes(); }
  function hm(min) { return ('0' + Math.floor(min / 60)).slice(-2) + ':' + ('0' + (min % 60)).slice(-2); }
  function textoVentana(f) { return f.map(function (x) { return hm(x[0]) + ' a ' + hm(x[1]); }).join('; '); }

  // Si Nextbyn no informa la hora de entrega, se toma la hora en que este reporte vio el cambio
  // de pendiente a entregado (precisión: el intervalo de actualización). Si el cliente ya figuraba
  // entregado la primera vez que el reporte lo vio, la hora queda desconocida.
  function registrarObservaciones() {
    if (!nb || !esHoy()) return;
    var hoyS = new Date().toDateString(), obs = leerLS(CLAVE_OBS, {});
    if (obs.dia !== hoyS) obs = { dia: hoyS, c: {} };
    var t = nb.at || Date.now();
    Object.keys((nb.cli && nb.cli.p) || {}).forEach(function (pat) {
      var P = nb.cli.p[pat];
      Object.keys(P).forEach(function (id) {
        var k = pat + '|' + id, o = obs.c[k] || {}, est = estadoNextbyn(P[id].estado);
        if (!est) o.pend = t;
        else if (!o.ent && o.pend) o.ent = t;
        else if (!o.ent && !o.pend) o.antes = 1;
        obs.c[k] = o;
      });
    });
    guardarLS(CLAVE_OBS, obs);
  }
  function horaEntrega(pat, c) {
    if (c.horaChess) return { t: c.horaChess, fuente: 'chess', prox: c.proximidad };
    if (c.horaNb) return { t: c.horaNb, fuente: 'nextbyn' };
    var obs = leerLS(CLAVE_OBS, {});
    var o = obs.dia === new Date().toDateString() && obs.c && obs.c[pat + '|' + (c.codigo || '')];
    if (o && o.ent) return { t: o.ent, fuente: 'reporte' };
    return null;
  }

  // Evalúa un cliente. st: ok (a tiempo), fuera, sinhora, vencido, pend, rech.
  function evaluarOT(pat, c, ahora) {
    var v = vt && vt.mapa && c.codigo ? vt.mapa[c.codigo] : null;
    var f = v ? v.f : [], r = { f: f, nota: v ? v.nota : '', sinVentana: !f.length };
    var entregado = c.est === 'entregado' || c.est === 'parcial';
    if (c.est === 'rechazado') { r.st = 'rech'; r.dev = clienteDevolucion(c); return r; }
    if (entregado) {
      if (r.sinVentana) { r.st = 'ok'; r.h = horaEntrega(pat, c); return r; }
      r.h = horaEntrega(pat, c);
      if (!r.h) { r.st = 'sinhora'; return r; }
      var m = minDelDia(r.h.t);
      r.st = f.some(function (x) { return m >= x[0] && m <= x[1]; }) ? 'ok' : 'fuera';
      r.temprano = r.st === 'fuera' && m < f[0][0];
      return r;
    }
    var am = minDelDia(ahora);
    r.st = !r.sinVentana && am > f[f.length - 1][1] ? 'vencido' : 'pend';
    var p = proyeccion(pat, ahora).porCli[claveCli(c)];
    if (p) { r.eta = p.eta; r.riesgo = p.riesgo; r.pos = p.pos; r.minCli = p.m; }
    return r;
  }

  // ---------- proyección: clientes en riesgo de llegar fuera de ventana ----------
  // Orden de visita: secuencia de Nextbyn. Tiempo por cliente: promedio de las últimas entregas
  // de hoy (si hay al menos 3 con hora); si no, el ritmo del camión desde que salió.
  var cacheProy = {};
  function claveCli(c) { return c.codigo || c.cliente; }
  // Llegada estimada a cada pendiente, en el orden de la secuencia (ruta óptima de la app u hoja de ruta):
  // se parte de la última visita (o del cliente con check-in abierto, o del CD si todavía no visitó a nadie)
  // y se suma el manejo entre clientes (línea recta × 1,3 a 25 km/h) más la demora de cada cliente
  // (fijada a mano, la de su historial de check-in o la general).
  function proyeccion(pat, ahora) {
    var dv = window.LTChoferes && LTChoferes.demVersion ? LTChoferes.demVersion() : 0;
    var k = pat + '|' + (nb && nb.at) + '|' + (ch && ch.at) + '|' + (vt && vt.at) + '|' + Math.floor(ahora / 6e4) + '|' + dv + '|' + cfg.demora + '|' + cfg.cdLL;
    if (cacheProy[k]) return cacheProy[k];
    var lista = listaClientes(pat), res = { porCli: {}, riesgo: 0, justo: 0, m: null };
    var llDe = function (c) { var v = vt && vt.mapa && c.codigo ? vt.mapa[c.codigo] : null; return v && v.ll ? v.ll : null; };
    // Punto de partida: la última visita con hora.
    var ult = null;
    lista.forEach(function (c) { if (!c.est) return; var h = horaEntrega(pat, c); if (h && h.t && (!ult || h.t > ult.t)) ult = { t: +new Date(h.t), ll: llDe(c) }; });
    var t, pos;
    if (ult) { t = Math.max(ahora.getTime(), ult.t); pos = ult.ll || cfg.cdLL; }
    else {
      var cam = nb && nb.cams.filter(function (x) { return String(x.patente).toUpperCase() === pat; })[0];
      var ini = cam && cam.inicio ? new Date(cam.inicio) : null;
      if (!ini || ini.getHours() < 4) ini = aHora(ahora, ventanaApertura(ahora)[0]);
      t = Math.max(ahora.getTime(), ini.getTime()); pos = cfg.cdLL;
    }
    var pend = lista.filter(function (c) { return !c.est; });
    pend.sort(function (a, b) {
      if (a.enCliente || b.enCliente) return (b.enCliente ? 1 : 0) - (a.enCliente ? 1 : 0); // el que tiene check-in va primero
      var sa = a.seq == null ? 1e9 : a.seq, sb = b.seq == null ? 1e9 : b.seq;
      return sa - sb || String(a.cliente).localeCompare(b.cliente);
    });
    var sumaDem = 0;
    pend.forEach(function (c, i) {
      var ll = llDe(c), dem = demoraPlan(c.codigo).min, eta;
      if (c.enCliente) { eta = c.enCliente; t = Math.max(ahora.getTime(), c.enCliente + dem * 6e4); }
      else {
        if (pos && ll) t += kmEntre(pos, ll) / VEL_KMH * 36e5;
        eta = t;
        t += dem * 6e4;
      }
      if (ll) pos = ll;
      sumaDem += dem;
      var v = vt && vt.mapa && c.codigo ? vt.mapa[c.codigo] : null, f = v ? v.f : [];
      var dias = Math.floor((new Date(eta).setHours(0, 0, 0, 0) - new Date(ahora).setHours(0, 0, 0, 0)) / 864e5);
      var em = minDelDia(eta) + dias * 1440, riesgo = 'sin';
      if (f.length && minDelDia(ahora) > f[f.length - 1][1]) riesgo = 'vencido'; // ya se perdió: no cuenta como riesgo
      else if (f.length) {
        var dentro = f.filter(function (x) { return em >= x[0] && em <= x[1]; })[0];
        if (dentro) riesgo = dentro[1] - em < dem ? 'justo' : 'ok';
        else if (f.some(function (x) { return x[0] > em; })) riesgo = 'antes';
        else riesgo = 'riesgo';
      }
      if (riesgo === 'riesgo') res.riesgo++;
      if (riesgo === 'justo') res.justo++;
      res.porCli[claveCli(c)] = { eta: eta, riesgo: riesgo, pos: i + 1, m: dem, enCliente: !!c.enCliente };
    });
    res.m = pend.length ? sumaDem / pend.length : +cfg.demora || 10;
    res.fin = pend.length ? new Date(t + (pos && cfg.cdLL ? kmEntre(pos, cfg.cdLL) / VEL_KMH * 36e5 : 0)) : null;
    if (Object.keys(cacheProy).length > 200) cacheProy = {};
    cacheProy[k] = res;
    return res;
  }
  // OT del camión: entregados dentro de la ventana sobre el total de pedidos del día.
  function otDeCamion(pat, ahora) {
    var lista = listaClientes(pat);
    var r = { total: lista.length, ok: 0, fuera: 0, vencido: 0, sinhora: 0, rech: 0, pend: 0 };
    lista.forEach(function (c) { r[evaluarOT(pat, c, ahora).st]++; });
    // OT en vivo: a tiempo sobre visitados con resultado conocido (a tiempo, fuera de ventana, rechazado).
    r.visitados = r.ok + r.fuera + r.rech;
    return r;
  }
  function listaClientes(pat) {
    var nbCli = (nb && nb.cli && nb.cli.p && nb.cli.p[pat]) || {};
    var dc = ch && ch.data && ch.data[pat];
    if (dc) return cruzar(dc, nbCli);
    return Object.keys(nbCli).map(function (id) {
      var x = nbCli[id];
      return { codigo: id.indexOf('N:') ? id : '', cliente: (id.indexOf('N:') ? id + ' - ' : '') + x.nombre, domicilio: x.domicilio, nbEstado: x.estado, motivos: x.motivo ? [x.motivo] : [], horaNb: x.hora || null, seq: x.seq != null ? x.seq : null, n: x.n != null ? x.n : null, demora: x.demora != null ? x.demora : null, enCliente: x.enCliente || null, optPos: x.optPos || null, nc: x.nc || null, leidoNextbyn: true, est: estadoNextbyn(x.estado) };
    });
  }
  function pct(a, b) { return b ? Math.round((a / b) * 100) + '%' : '—'; }

  // Mini línea del día de un cliente: ventana(s) sombreada(s) y la hora de entrega.
  var TXT_OT = { ok: 'A tiempo', fuera: 'Fuera de ventana', sinhora: 'Sin hora de entrega', vencido: 'Ventana vencida', pend: 'Pendiente', rech: 'Rechazado' };
  function lineaCliente(r, E, ahora) {
    var h = '<div class="ot-linea" title="' + esc(tituloOT(r)) + '"><div class="carril"></div>';
    r.f.forEach(function (x) {
      var a = aHora(ahora, hm(x[0])), b = aHora(ahora, hm(x[1]));
      h += '<div class="ot-ven" style="left:' + E.x(a) + '%;width:' + Math.max(0.8, E.x(b) - E.x(a)) + '%"></div>';
    });
    if (r.h) h += '<div class="ot-pto ' + r.st + '" style="left:' + E.x(r.h.t) + '%"></div>';
    if (r.eta && r.st === 'pend') h += '<div class="ot-eta ' + r.riesgo + '" style="left:' + E.x(r.eta) + '%"></div>';
    h += '<div class="ahora" style="left:' + E.x(ahora) + '%"></div></div>';
    var sub = r.f.length ? textoVentana(r.f) : 'Sin ventana';
    if (r.h) sub += (r.h.fuente === 'reporte' ? ', visto entregado ' : ', entregó ') + hhmm(r.h.t);
    if (r.eta && r.st === 'pend') {
      var cierre = r.f.length ? hm(r.f[r.f.length - 1][1]) : '';
      return h + '<span class="ot-txt pend ' + r.riesgo + '"><b>' + TXT_RIESGO[r.riesgo] + '</b> ' + esc(sub) + ', llega ~' + hhmm(r.eta) +
        (r.riesgo === 'riesgo' ? ' (cierra ' + cierre + ')' : '') + '</span>';
    }
    return h + '<span class="ot-txt ' + r.st + '"><b>' + (r.dev ? 'Devolución' : TXT_OT[r.st]) + (r.temprano ? ' (antes)' : '') + '</b> ' + esc(sub) + '</span>';
  }
  var TXT_RIESGO = { riesgo: 'En riesgo', justo: 'Justo', antes: 'Llega antes', ok: 'Pendiente', sin: 'Pendiente' };
  function tituloOT(r) {
    var t = (r.eta && r.st === 'pend' ? TXT_RIESGO[r.riesgo] + '. Llegada estimada ' + hhmm(r.eta) + ' (' + r.pos + '.º en la secuencia; demora de este cliente ' + fmtMin(r.minCli) + ', manejo a ' + VEL_KMH + ' km/h)' : TXT_OT[r.st]) + '. Ventana: ' + (r.f.length ? textoVentana(r.f) : 'sin ventana (el OT se da por cumplido)');
    if (r.h) t += '. Entrega: ' + hhmm(r.h.t) + (r.h.fuente === 'reporte' ? ' (hora en que el reporte vio el cambio)' : r.h.fuente === 'chess' ? ' (liquidación de Chess' + (r.h.prox ? ', a ' + Math.round(r.h.prox) + ' m del cliente' : '') + ')' : ' (Nextbyn)');
    if (r.st === 'sinhora') t += '. Ni la liquidación de Chess ni Nextbyn informan la hora de esta entrega.';
    return t;
  }
  function resumenRiesgo(pat, ahora) {
    var p = proyeccion(pat, ahora);
    if (!p || (!p.riesgo && !p.justo && !Object.keys(p.porCli).length)) return '';
    var fuente = nb && nb.fuente === 'app' ? 'orden de la hoja de ruta publicada para la app' : nb && nb.cli && nb.cli.colSeq ? 'columna ' + nb.cli.colSeq + ' de Nextbyn' : 'orden de la lista de Clientes de Nextbyn';
    return '<span class="ot-res" title="' + esc('Secuencia: ' + fuente + '. Llegadas: desde la última visita, manejo entre clientes a ' + VEL_KMH + ' km/h más la demora de cada cliente (promedio ' + fmtMin(p.m) + ').') + '">En riesgo <b>' + p.riesgo + '</b> <small>' + (p.justo ? p.justo + ' justos, ' : '') + 'demora prom. ' + fmtMin(p.m) + (p.fin ? ' · vuelve al CD ~' + hhmm(p.fin) : '') + '</small></span>';
  }
  // ---------- ruta óptima de la app: orden de los pendientes y cumplimiento ----------
  function optDe(pat) {
    var cam = nb && nb.cams && nb.cams.filter(function (x) { return String(x.patente).toUpperCase() === pat; })[0];
    return cam && cam.optimo ? cam.optimo : null;
  }
  function posOptimo(c) { return !c.est && c.optPos ? '<span class="opt-pos" title="Orden en la ruta óptima que calculó la app">' + c.optPos + '.º en ruta óptima</span>' : ''; }
  // ---------- demora en el cliente (check-in de la app → estado de la visita) ----------
  function fmtMin(m) { return (Math.round(m * 10) / 10).toFixed(1).replace('.', ',').replace(',0', '') + ' min'; }
  // Demora que usa el horario proyectado para un cliente: manual > historial de check-in > general.
  function demoraPlan(cod) {
    var d = cod && window.LTChoferes && LTChoferes.demoraCliente ? LTChoferes.demoraCliente(cod) : null;
    return d ? d : { min: Math.max(0, +cfg.demora || 0), fuente: 'general', n: 0 };
  }
  function lineaPlanDemora(c) {
    if (!modoApp() || !c.codigo) return '';
    var d = demoraPlan(c.codigo), edita = window.LTChoferes && LTChoferes.puedeEditarDemora && LTChoferes.puedeEditarDemora();
    var t = d.fuente === 'manual' ? 'fijada ' + fmtMin(d.min) : d.fuente === 'historial' ? 'estimada ' + fmtMin(d.min) : 'general ' + fmtMin(d.min);
    var tit = d.fuente === 'manual' ? 'Demora fijada a mano' + (d.por ? ' por ' + d.por : '') + (d.hist != null ? '. Según su historial sería ' + fmtMin(d.hist) + ' (' + d.n + ' visitas).' : '.')
      : d.fuente === 'historial' ? 'Promedio de las últimas ' + d.n + ' visitas con check-in (sin la más larga ni la más corta si hay 5 o más).'
      : 'Todavía no hay visitas con check-in: se usa la demora general de arriba.';
    return '<span class="dem-plan ' + d.fuente + '" title="' + esc(tit) + '">' + t + (d.fuente === 'historial' ? ' · ' + d.n + (d.n === 1 ? ' visita' : ' visitas') : '') +
      (edita ? ' <button type="button" class="dem-edit" data-dem="' + esc(c.codigo) + '" data-nom="' + esc(String(c.cliente).replace(/^\s*\d+\s*-\s*/, '')) + '" data-min="' + (Math.round(d.min * 10) / 10) + '" data-man="' + (d.fuente === 'manual' ? 1 : 0) + '" aria-label="Cambiar la demora de este cliente">✎</button>' : '') + '</span>';
  }
  function celdaDemora(c) { return celdaDemoraHoy(c) + lineaPlanDemora(c); }
  function celdaDemoraHoy(c) {
    if (c.enCliente) return '<span class="dem en" data-ci="' + c.enCliente + '" title="Check-in a las ' + hhmm(c.enCliente) + '">En el cliente <b>' + fmtMin((Date.now() - c.enCliente) / 6e4) + '</b></span>';
    if (c.demora == null) return '<span class="dem nada" title="Sin check-in en la app">—</span>';
    var lim = +cfg.demora || 10;
    return '<span class="dem ' + (c.demora > lim * 1.5 ? 'mal' : c.demora > lim ? 'medio' : 'bien') + '">' + fmtMin(c.demora) + '</span>';
  }
  function demoraProm(lista) {
    var d = lista.filter(function (c) { return c.demora != null; }).map(function (c) { return c.demora; });
    return { n: d.length, prom: d.length ? d.reduce(function (a, b) { return a + b; }, 0) / d.length : null };
  }
  function resumenDemora(lista) {
    if (!modoApp()) return '';
    var d = demoraProm(lista), lim = +cfg.demora || 10, en = lista.filter(function (c) { return c.enCliente; })[0];
    return '<span class="ot-res dem-res" title="Demora por cliente: la configurada arriba (la usa el horario proyectado). Demora actual: promedio real entre el check-in y el estado de la visita en la app.">' +
      'Demora por cliente <b>' + fmtMin(lim) + '</b> · actual <b class="' + (d.prom == null ? '' : d.prom > lim * 1.5 ? 'mal' : d.prom > lim ? 'medio' : 'bien') + '">' + (d.prom == null ? '—' : fmtMin(d.prom)) + '</b>' +
      ' <small>' + (d.n ? d.n + (d.n === 1 ? ' visita' : ' visitas') + ' con check-in' : 'sin check-in todavía') + (en ? ' · ahora en ' + esc(String(en.cliente).replace(/^\s*\d+\s*-\s*/, '')) : '') + '</small></span>';
  }
  function demoraFlota() {
    var t = 0, n = 0;
    ((nb && nb.cams) || []).forEach(function (cam) {
      var d = demoraProm(listaClientes(String(cam.patente).toUpperCase()));
      if (d.n) { t += d.prom * d.n; n += d.n; }
    });
    return { n: n, prom: n ? t / n : null };
  }
  setInterval(function () {
    Array.prototype.forEach.call(document.querySelectorAll('.dem.en'), function (el) { el.querySelector('b').textContent = fmtMin((Date.now() - +el.getAttribute('data-ci')) / 6e4); });
  }, 15000);
  function nivelCump(o) { return !o.n ? '' : o.ok / o.n >= 0.85 ? 'bien' : o.ok / o.n >= 0.65 ? 'medio' : 'mal'; }
  function resumenOptimo(pat) {
    if (!modoApp()) return '';
    var o = optDe(pat);
    if (!o) return '<span class="ot-res opt-res" title="El chofer todavía no calculó la ruta óptima en la app">Ruta óptima <small>sin calcular</small></span>';
    var c = o.cump;
    return '<span class="ot-res opt-res ' + nivelCump(c) + '" title="Visitas hechas en el orden de la ruta óptima, desde que se calculó. Saltear un cliente cuenta una vez.' + (c.fuera.length ? ' Fuera de orden: ' + esc(c.fuera.join(', ')) : '') + '">' +
      'Cumplimiento ruta óptima <b>' + pct(c.ok, c.n) + '</b> <small>' + c.ok + ' de ' + c.n + ' visitas en orden · calculada ' + hhmm(o.at) + (o.planes > 1 ? ' (' + o.planes + ' veces)' : '') +
      (o.km != null ? ' · ' + String(o.km).replace('.', ',') + ' km' : '') + '</small></span>';
  }
  function cumplimientoFlota() {
    var r = { ok: 0, n: 0, cam: 0, con: 0 };
    ((nb && nb.cams) || []).forEach(function (x) { r.cam++; if (x.optimo) { r.con++; r.ok += x.optimo.cump.ok; r.n += x.optimo.cump.n; } });
    return r;
  }
  function resumenOT(o) {
    return '<span class="ot-res" title="OT en vivo: a tiempo sobre clientes ya visitados (entregados o rechazados; no cuenta los entregados sin hora)">OT en vivo <b>' + pct(o.ok, o.visitados) + '</b> <small>' + o.ok + ' de ' + o.visitados + ' visitados</small></span>' +
      '<span class="ot-res">OT del día <b>' + pct(o.ok, o.total) + '</b> <small>' + o.ok + ' de ' + o.total + ' a tiempo' +
      (o.fuera ? ', ' + o.fuera + ' fuera de ventana' : '') + (o.vencido ? ', ' + o.vencido + ' con ventana vencida' : '') +
      (o.sinhora ? ', ' + o.sinhora + ' sin hora' : '') + '</small></span>';
  }

  // Rechazos primero, después pendientes (en la secuencia de Nextbyn) y al final los entregados en el orden en que se entregaron.
  function ordenarClientes(pat, lista, ahora) {
    lista.forEach(function (c) { var h = horaEntrega(pat, c); c._t = h ? h.t : Infinity; });
    lista.sort(function (a, b) {
      var sa = a.seq == null ? 1e9 : a.seq, sb = b.seq == null ? 1e9 : b.seq;
      return orden(a) - orden(b) || (orden(a) === 2 ? a._t - b._t : 0) || (orden(a) === 1 ? sa - sb : 0) || String(a.cliente).localeCompare(b.cliente);
    });
  }

  // Productos del cliente: si hubo rechazo, primero un resumen (total o parcial) y los SKU rechazados.
  function detalleProductos(c) {
    var items = c.items || [], rech = items.filter(function (it) { return it.rechazado; }), ent = items.filter(function (it) { return !it.rechazado; });
    var dev = rech.length > 0 && rech.every(esDevolucion), mixto = !dev && rech.some(esDevolucion);
    var suma = function (l, k) { return l.reduce(function (a, it) { return a + (+it[k] || 0); }, 0); };
    var fila = function (it) {
      return '<tr' + (it.rechazado ? ' class="sku-rech"' : '') + '><td>' + esc(it.articulo) + (it.ret ? ' <span class="pill p-pe">RET</span>' : '') +
        (mixto && esDevolucion(it) ? ' <span class="pill p-pe">Devolución</span>' : '') +
        '</td><td class="n">' + num(it.bultos) + ' bultos</td><td class="n">' + plata(it.importe) + '</td></tr>';
    };
    var h = '';
    if (rech.length) {
      var total = !ent.length;
      var bR = suma(rech, 'bultos'), bT = suma(items, 'bultos');
      var titulo = dev ? (total ? 'Devolución total' : 'Devolución parcial') : (total ? 'Rechazo total' : 'Rechazo parcial');
      h += '<div class="rech-res ' + (total ? 'total' : 'parcial') + '"><b>' + titulo + '</b> ' +
        rech.length + ' de ' + items.length + ' SKU, ' + num(bR) + ' de ' + num(bT) + ' bultos (' + (bT ? Math.round((bR / bT) * 100) : 0) + '%), ' +
        plata(suma(rech, 'importe')) + ' de ' + plata(suma(items, 'importe')) +
        (c.motivos && c.motivos.length ? '. Motivo: ' + esc(c.motivos.join(', ')) : '') +
        (mixto ? '. Incluye ' + rech.filter(esDevolucion).length + ' SKU de devolución.' : '') + '</div>';
      if (!rech.some(function (it) { return it.usuario; })) h += '<p class="h-nota" title="' + esc('Columnas del reporte de Chess: ' + ((ch && ch.camposRep) || 'sin datos')) + '">Chess no informa el usuario emisor de este rechazo, así que no se puede distinguir si es devolución.</p>';
      h += '<table class="skus"><tbody><tr class="sub"><td colspan="3">' + (dev ? 'SKU devueltos' : 'SKU rechazados') + ' (' + rech.length + ')</td></tr>' + rech.map(fila).join('');
      if (ent.length) h += '<tr class="sub"><td colspan="3">SKU entregados (' + ent.length + ')</td></tr>' + ent.map(fila).join('');
      return h + '</tbody></table>';
    }
    var aviso = c.est === 'rechazado' || c.est === 'parcial' ? '<div class="rech-res parcial"><b>' + (c.est === 'rechazado' ? 'Rechazo total' : 'Rechazo parcial') + ' según Nextbyn</b> Chess todavía no tiene cargado qué SKU se rechazaron.</div>' : '';
    return aviso + '<table class="skus"><tbody>' + items.map(fila).join('') + '</tbody></table>';
  }

  function notaVentana(r) { return r.nota ? '<span class="ot-nota" title="Sin ventana horaria: el OT se da por cumplido">⚠ ' + esc(r.nota) + '</span>' : ''; }
  function avisoOT() {
    if (!vt) return '<span class="ot-aviso">' + (errVt ? 'No se pudo leer la hoja de ventanas: ' + esc(errVt) : 'Leyendo ventanas horarias…') + '</span>';
    if (ch && ch.liq && ch.liq.camiones) return ch.liq.error ? '<span class="ot-aviso" title="' + esc(ch.liq.error) + '">Algunas liquidaciones de Chess no se pudieron leer.</span>' : '';
    if (ch && ch.liq && ch.liq.error) return '<span class="ot-aviso" title="' + esc(ch.liq.error) + '">No se pudo leer la liquidación de Chess: la hora de entrega sale de Nextbyn o de cuándo el reporte vio el cambio.</span>';
    if (!ch) return '<span class="ot-aviso">La hora de entrega sale de la liquidación de Chess: tocá Chess arriba.</span>';
    return '';
  }

  function detalle(cam, E, ahora) {
    var pat = String(cam.patente).toUpperCase();
    var nbCli = (nb && nb.cli && nb.cli.p && nb.cli.p[pat]) || {};
    var hayNb = !!(nb && nb.cli && nb.cli.n);
    var dc = ch && ch.data && ch.data[pat];

    // Sin Chess: lista de Nextbyn sola.
    if (!dc) {
      var ids = Object.keys(nbCli);
      var msg = !ch ? (errCh ? 'Chess: ' + esc(errCh) : 'Tocá <b>Chess</b> arriba para sumar importes, bultos y cajones.') : 'Chess no tiene planilla con entrega hoy para ' + esc(pat) + '.';
      if (!ids.length) return '<div class="dres">' + msg + '</div>';
      var lista = listaClientes(pat);
      ordenarClientes(pat, lista, ahora);
      return '<div class="dres"><span>' + msg + '</span><span>Clientes <b>' + lista.length + '</b></span><span>Entregados <b>' + lista.filter(function (c) { return c.est === 'entregado'; }).length + '</b></span>' + resumenOT(otDeCamion(pat, ahora)) + resumenOptimo(pat) + resumenDemora(lista) + resumenRiesgo(pat, ahora) + avisoOT() + '</div>' +
        '<div class="tabla-cli"><table class="cli"><thead><tr><th>Estado</th><th>Cliente</th><th class="h-ot">Ventana y entrega</th><th class="h-dem">Demora</th><th class="h-pago">Pago pendiente</th><th class="h-dom">Domicilio</th></tr></thead><tbody>' +
        lista.map(function (c) { var r = evaluarOT(pat, c, ahora); return '<tr><td>' + pillEstado(c) + '</td><td><b>' + esc(c.cliente) + '</b>' + posOptimo(c) + notaVentana(r) + '</td><td class="h-ot">' + lineaCliente(r, E, ahora) + '</td><td class="h-dem">' + celdaDemora(c) + '</td><td class="h-pago">' + pillPago(c) + '</td><td class="h-dom">' + esc(c.domicilio) + '</td></tr>'; }).join('') + '</tbody></table></div>';
    }

    // Con Chess: cruza cada cliente con su estado en Nextbyn.
    var cs = cruzar(dc, nbCli);
    ordenarClientes(pat, cs, ahora);
    var nRe = cs.filter(function (c) { return c.est === 'rechazado' || c.est === 'parcial'; }).length;
    var nEnt = cs.filter(function (c) { return c.est === 'entregado'; }).length;
    var h = '<div class="dres"><span>Chofer <b>' + esc(String(dc.chofer || '').replace(/^\d+\s*-\s*/, '')) + '</b></span>' +
      '<span>Planillas <b>' + esc(dc.planillas.join(', ')) + '</b></span>' +
      '<span>Clientes <b>' + cs.length + '</b></span><span>Entregados <b>' + nEnt + '</b></span>' + (nRe ? '<span>Rechazos <b>' + nRe + '</b></span>' : '') +
      '<span>Importe <b>' + plata(dc.importe) + '</b></span><span>Bultos <b>' + Math.round(dc.bultos) + '</b></span>' +
      '<span>Cajones retornables <b>' + Math.round(dc.cajones) + '</b></span>' +
      (hayNb ? '' : '<span>Sin estados de Nextbyn: el estado sale de Chess.</span>') + resumenOT(otDeCamion(pat, ahora)) + resumenOptimo(pat) + resumenDemora(cs) + resumenRiesgo(pat, ahora) + avisoOT() + '</div>' +
      '<div class="tabla-cli"><table class="cli"><thead><tr><th>Estado</th><th>Cliente</th><th class="h-ot">Ventana y entrega</th><th class="h-dem">Demora</th><th class="h-pago">Pago pendiente</th><th class="h-dom">Domicilio</th><th class="h-loc">Localidad</th><th class="h-comp">Comprobante</th><th class="n">Importe</th><th class="n">Bultos</th><th class="n">Cajones</th></tr></thead><tbody>';
    cs.forEach(function (c) {
      var k = pat + '|' + c.cliente, abierto = !!clientesAbiertos[k], rOT = evaluarOT(pat, c, ahora);
      h += '<tr class="cl" data-cl="' + esc(k) + '"><td>' + pillEstado(c) +
        (c.motivos && c.motivos.length ? '<span class="motivo">' + esc(c.motivos.join(', ')) + '</span>' : '') +
        '</td><td><span class="car' + (abierto ? ' rot' : '') + '">▸</span><b>' + esc(c.cliente) + '</b>' + posOptimo(c) + notaVentana(rOT) + '</td><td class="h-ot">' + lineaCliente(rOT, E, ahora) + '</td><td class="h-dem">' + celdaDemora(c) + '</td><td class="h-pago">' + pillPago(c) + '</td><td class="h-dom">' + esc(c.domicilio) + '</td><td class="h-loc">' + esc(c.localidad) +
        '</td><td class="h-comp" style="font-size:13px">' + esc(c.comprobantes.join(', ')) + '</td><td class="n">' + plata(c.importe) + '</td><td class="n">' + num(c.bultos) + '</td><td class="n">' + num(c.cajones) + '</td></tr>';
      if (abierto) {
        h += '<tr class="prod"><td colspan="11">' + detalleProductos(c) + '</td></tr>';
      }
    });
    return h + '</tbody></table></div>';
  }

  // ---------- pintar ----------
  function pintarFuente(btn, hora, ocup, err, datos) {
    btn.disabled = ocup;
    btn.className = 'fuente' + (ocup ? ' leyendo' : err ? ' error' : datos ? ' ok' : '');
    hora.textContent = ocup ? 'leyendo…' : err ? 'error' : datos ? hhmm(datos.at) : 'sin datos';
  }
  function pintarBotones() {
    var app = modoApp();
    $('n-nb').textContent = app ? 'App choferes' : 'Nextbyn';
    pintarFuente($('b-nb'), $('t-nb'), ocupado.nextbyn, errNb, nb);
    if (app && !nb) $('t-nb').textContent = 'conectando';
    pintarFuente($('b-ch'), $('t-ch'), ocupado.chess, errCh, ch);
    $('b-todo').disabled = ocupado.nextbyn && ocupado.chess;
    $('b-nb').title = app ? 'Las entregas llegan en vivo desde la app de choferes. Tocá para ir a la pestaña App choferes.'
      : errNb || (nb ? 'Datos de Nextbyn de las ' + hhmm(nb.at) + '. Tocá para volver a leer.' : 'Leer Nextbyn');
    $('b-ch').title = errCh || (ch ? 'Datos de Chess de las ' + hhmm(ch.at) + '. Tocá para volver a leer.' : 'Leer Chess');
  }

  function pintarSub() {
    var t = nb ? (nb.fuente === 'app' ? 'Entregas de la app de choferes, en vivo (último cambio ' + hhmm(nb.at) + '), ' : 'Datos de Nextbyn de las ' + hhmm(nb.at) + ', ') + ((nb.cli && nb.cli.n) || 0) + ' clientes.' : '';
    if (proxima) { var s = Math.max(0, Math.round((proxima - Date.now()) / 1000)); t += ' Próxima actualización en ' + Math.floor(s / 60) + ':' + ('0' + (s % 60)).slice(-2) + '.'; }
    $('sub').textContent = t.trim();
  }

  function pintar() {
    pintarBotones();
    pintarSub();
    if (window.LTMapa) setTimeout(window.LTMapa.refrescar, 0);
    var av = '';
    if (sinExtension) {
      av += '<div class="err">Para traer los datos hace falta la extensión <b>Tablero de ruta - LoToDeliver</b> en este Chrome. <a href="' + GUIA + '">Cómo instalarla</a>.</div>';
    } else {
      if (extVersion && extVersion !== VERSION_PAG) av += '<div class="err">La extensión instalada en este Chrome es la <b>v' + esc(extVersion) + '</b> y el tablero es la <b>v' + VERSION_PAG + '</b>. Reemplazala con el archivo nuevo y tocá recargar en chrome://extensions; si no, algunos datos (como los teléfonos de los clientes) no llegan a la app. <a href="' + GUIA + '">Cómo</a>.</div>';
      if (window.LTChoferes && LTChoferes.pendientesNC && LTChoferes.pendientesNC()) av += '<div class="aviso-nc">' + LTChoferes.pendientesNC() + (LTChoferes.pendientesNC() === 1 ? ' visita no concretada espera' : ' visitas no concretadas esperan') + ' tu respuesta para salvar la entrega. <a href="#choferes">Responder</a></div>';
      if (window.LTChoferes && LTChoferes.pendientes()) av += '<div class="aviso-desc">' + LTChoferes.pendientes() + (LTChoferes.pendientes() === 1 ? ' pedido de descuento espera' : ' pedidos de descuento esperan') + ' respuesta. <a href="#choferes">Responder</a></div>';
      if (errNb) av += '<div class="err">Nextbyn: ' + esc(errNb) + (nb ? ' Se muestran los datos de las ' + hhmm(nb.at) + '.' : '') + '</div>';
      if (errCh) av += '<div class="err">Chess: ' + esc(errCh) + (ch ? ' Se muestran los datos de las ' + hhmm(ch.at) + '.' : '') + '</div>';
    }
    $('aviso').innerHTML = av;
    $('vacio').hidden = !!nb;
    if (!nb && modoApp()) $('vacio').innerHTML = window.LTChoferes.conSesion() ? '<h2>Esperando la hoja de ruta ' + (esHoy() ? 'de hoy' : 'del ' + selDia.split('-').reverse().slice(0, 2).join('/')) + '</h2><p>Las entregas llegan desde la app de choferes. La hoja de ruta se publica sola cuando el Tablero lee <b>Chess</b>: tocá <b>Actualizar todo</b>.</p>'
      : '<h2>Entrá como modulador</h2><p>Las entregas llegan desde la app de choferes. Para verlas, entrá con tu usuario en la pestaña <a href="#choferes">App choferes</a>.</p>';
    if (!nb) { $('contenido').innerHTML = ''; return; }

    var ahora = ahoraRef();
    var cams = analizar(nb.cams, ahora);
    var riesgoF = 0;
    cams.forEach(function (e) {
      if (e.estado !== 'ABIERTA' || !e.pendientes) return;
      var p = proyeccion(String(e.patente).toUpperCase(), ahora);
      e.enRiesgo = p.riesgo;
      riesgoF += p.riesgo;
      if (p.riesgo) e.alertas.push(p.riesgo + (p.riesgo === 1 ? ' cliente en riesgo' : ' clientes en riesgo') + ' de llegar fuera de ventana');
    });
    var E = escala(cams, ahora);
    var cuenta = { rojo: 0, amarillo: 0, azul: 0, verde: 0, gris: 0 }, tot = { h: 0, r: 0, t: 0 };
    cams.forEach(function (e) { cuenta[e.sem]++; tot.h += e.hechos; tot.r += e.rechazos; tot.t += e.total; });
    var enRuta = cams.filter(function (e) { return e.estado === 'ABIERTA'; }).length;
    // OT de la flota: suma de los camiones con detalle de clientes.
    var otF = { ok: 0, total: 0, vis: 0, fuera: 0, rech: 0 }, otCam = {};
    cams.forEach(function (e) {
      var o = otDeCamion(String(e.patente).toUpperCase(), ahora);
      otCam[e.patente] = o;
      otF.ok += o.ok; otF.total += o.total; otF.vis += o.visitados;
      otF.fuera += o.fuera; otF.rech += o.rech;
    });

    // Resumen de la flota
    var nombres = { rojo: 'Demorados', amarillo: 'Ajustados', azul: 'Recién salen', verde: 'En horario', gris: 'Finalizados' };
    // Resumen de la flota en cuatro grupos: flota, avance, OT y alertas.
    var avance = tot.t ? Math.round((tot.h / tot.t) * 100) : 0;
    var otV = otF.vis ? otF.ok / otF.vis : 0;
    var nivel = function (v) { return v >= 0.9 ? 'bien' : v >= 0.75 ? 'medio' : 'mal'; };
    var h = '<section class="resumen" aria-label="Resumen de la flota">' +
      // Flota
      '<div class="grupo g-flota"><h2>Flota</h2>' +
      '<p class="dato"><b>' + enRuta + '</b> <span>en ruta de ' + cams.length + '</span></p>' +
      '<div class="comp-barra">' + Object.keys(cuenta).map(function (k) { return cuenta[k] ? '<i class="' + k + '" style="width:' + (cuenta[k] / cams.length) * 100 + '%" title="' + cuenta[k] + ' ' + nombres[k].toLowerCase() + '"></i>' : ''; }).join('') + '</div>' +
      '<div class="comp-ley">' + Object.keys(cuenta).map(function (k) { return '<span' + (cuenta[k] ? '' : ' class="cero"') + '><i class="' + k + '"></i><b>' + cuenta[k] + '</b> ' + nombres[k] + '</span>'; }).join('') + '</div></div>' +
      // Avance
      '<div class="grupo g-avance"><h2>Avance</h2>' +
      '<p class="dato"><b>' + avance + '%</b> <span>' + tot.h + ' de ' + tot.t + ' clientes visitados</span></p>' +
      '<div class="medidor"><i style="width:' + avance + '%"></i></div>' +
      '<p class="pie">Faltan ' + Math.max(0, tot.t - tot.h) + ' clientes</p>' +
      (modoApp() ? (function () {
        var f = cumplimientoFlota();
        return '<p class="pie opt-flota ' + nivelCump(f) + '" title="Visitas hechas en el orden de la ruta óptima calculada en la app, sobre las visitas hechas después de calcularla">Cumplimiento ruta óptima <b>' + pct(f.ok, f.n) + '</b> ' +
          (f.n ? f.ok + ' de ' + f.n + ' visitas en orden' : 'sin visitas con ruta óptima') + ' · ' + f.con + ' de ' + f.cam + ' camiones la calcularon</p>' +
          (function () { var d = demoraFlota(), lim = +cfg.demora || 10; return '<p class="pie" title="Promedio real entre el check-in y el estado de la visita en la app">Demora por cliente <b>' + fmtMin(lim) + '</b> · actual <b class="' + (d.prom == null ? '' : d.prom > lim * 1.5 ? 'mal' : d.prom > lim ? 'medio' : 'bien') + '">' + (d.prom == null ? '—' : fmtMin(d.prom)) + '</b> ' + (d.n ? d.n + ' visitas con check-in' : 'sin check-in todavía') + '</p>'; })();
      })() : '') + '</div>' +
      // OT
      '<div class="grupo g-ot"><h2>Entregas en ventana (OT)</h2><div class="dos">' +
      '<p class="dato ' + nivel(otV) + '" title="A tiempo sobre clientes ya visitados (entregados o rechazados)"><b>' + pct(otF.ok, otF.vis) + '</b> <span>en vivo<br>' + otF.ok + ' de ' + otF.vis + ' visitados</span></p>' +
      '<p class="dato" title="Pedidos entregados dentro de su ventana sobre el total de pedidos del día"><b>' + pct(otF.ok, otF.total) + '</b> <span>del día<br>sobre ' + otF.total + ' pedidos</span></p></div>' +
      '<div class="medidor ot" title="De los visitados: a tiempo, fuera de ventana y rechazados">' +
      (otF.vis ? '<i class="ok" style="width:' + (otF.ok / otF.vis) * 100 + '%"></i><i class="fuera" style="width:' + (otF.fuera / otF.vis) * 100 + '%"></i><i class="rech" style="width:' + (otF.rech / otF.vis) * 100 + '%"></i>' : '') + '</div>' +
      '<p class="pie"><i class="ok"></i>' + otF.ok + ' a tiempo <i class="fuera"></i>' + otF.fuera + ' fuera de ventana <i class="rech"></i>' + otF.rech + ' rechazados</p></div>' +
      // Alertas
      '<div class="grupo g-alertas"><h2>A revisar</h2>' +
      '<p class="dato' + (riesgoF ? ' mal' : '') + '" title="Pendientes que, con el ritmo actual y la secuencia de Nextbyn, llegarían después de que cierre su ventana"><b>' + riesgoF + '</b> <span>' + (riesgoF === 1 ? 'cliente' : 'clientes') + ' en riesgo de llegar fuera de ventana</span></p>' +
      '<p class="dato chico' + (tot.r ? ' mal' : '') + '"><b>' + tot.r + '</b> <span>' + (tot.r === 1 ? 'rechazo' : 'rechazos') + '</span></p></div>' +
      '</section>';

    // Rutas con su línea del día
    h += '<div class="layout' + (alAbierto ? '' : ' al-min') + '"><section class="rutas" aria-label="Rutas de hoy"><div class="eje"><span>Camión</span><span>Estado</span>' + eje(E, ahora) +
      '<span class="n">Clientes</span><span class="n">Ritmo</span><span class="n">Fin est.</span></div>';
    cams.forEach(function (e) {
      var abierto = !!abiertos[e.patente];
      var ancho = function (x) { return e.total ? (x / e.total) * 100 : 0; };
      h += '<div class="fila' + (abierto ? ' open' : '') + '" data-p="' + esc(e.patente) + '" style="--c:' + COLOR[e.sem] + '" tabindex="0" role="button" aria-expanded="' + abierto + '">' +
        '<div class="c-chapa">' + chapa(e.patente) + '<span class="veh">' + esc(e.vehiculo) + '</span></div>' +
        '<div class="estado"><b><i></i>' + esc(e.txt) + '</b>' +
        e.alertas.filter(function (a) { return a.indexOf('Cerró la jornada') !== 0; }).map(function (a) { return '<span class="al">' + esc(a) + '</span>'; }).join('') +
        (e.aviso ? '<span class="al sec">' + esc(e.aviso) + '</span>' : '') +
        (e.estado === 'ABIERTA' && e.pendientes ? '<button type="button" class="prio" data-prio="' + esc(e.patente) + '" aria-haspopup="dialog">Prioridad pedidos pendientes <span>' + cantidadPendientes(e) + '</span></button>' : '') + '</div>' +
        lineaDelDia(e, E, ahora) +
        '<div class="c-cli n"><span class="big">' + e.hechos + '</span><span style="color:var(--tenue)">/' + e.total + '</span>' +
        '<div class="avance" title="' + e.entregados + ' entregados, ' + e.parciales + ' parciales, ' + e.rechazos + ' rechazos, ' + e.pendientes + ' pendientes"><i class="e" style="width:' + ancho(e.entregados) + '%"></i><i class="p" style="width:' + ancho(e.parciales) + '%"></i><i class="r" style="width:' + ancho(e.rechazos) + '%"></i></div>' +
        (otCam[e.patente] && otCam[e.patente].total ? '<span class="mini" title="OT en vivo: a tiempo sobre visitados (' + otCam[e.patente].ok + ' de ' + otCam[e.patente].visitados + '). OT del día: ' + pct(otCam[e.patente].ok, otCam[e.patente].total) + ' sobre ' + otCam[e.patente].total + ' pedidos.">OT vivo ' + pct(otCam[e.patente].ok, otCam[e.patente].visitados) + '</span>' : '') + '</div>' +
        '<div class="c-ritmo n"><span class="big">' + (e.ritmo ? e.ritmo.toFixed(1) : '—') + '</span><span class="mini">cli/h</span></div>' +
        '<div class="c-fin n"' + (e.plan ? ' title="' + esc(textoPlan(e.plan)) + '"' : '') + '><span class="big">' + (e.fin ? hhmm(e.fin) : '—') + '</span><span class="mini">' +
        (e.plan ? '<b class="plan-txt' + (e.plan.fin > aHora(ahora, objetivo(ahora)) ? ' tarde' : '') + '">plan ' + hhmm(e.plan.fin) + '</b> ' : '') +
        (e.fin && e.fin.toDateString() !== ahora.toDateString() ? 'mañana' : e.estado === 'ABIERTA' && e.pendientes ? (e.sinAvanceMin < 1 ? 'visita hace <1 min' : 'visita hace ' + Math.round(e.sinAvanceMin) + ' min') : e.estado === 'CERRADA' ? 'cerrada' : '') +
        '</span></div></div>';
      if (abierto) h += '<div class="det">' + detalle(e, E, ahora) + '</div>';
    });
    h += '</section>';

    // Columna de alertas, agrupadas por camión
    var conAlertas = cams.filter(function (e) { return e.alertas.length; });
    var nAl = conAlertas.reduce(function (s, e) { return s + e.alertas.length; }, 0);
    var alRojo = conAlertas.some(function (e) { return e.sem === 'rojo'; });
    h += '<aside class="alertas' + (alAbierto ? '' : ' min') + '"><button type="button" class="al-tog" aria-expanded="' + alAbierto + '" title="' + (alAbierto ? 'Minimizar alertas' : 'Ver alertas') + '">' +
      '<span class="al-tit">Alertas</span><span class="al-n' + (nAl ? (alRojo ? ' rojo' : ' hay') : '') + '">' + nAl + '</span><span class="al-fl" aria-hidden="true">' + (alAbierto ? '›' : '‹') + '</span></button>' +
      (!alAbierto ? '' : conAlertas.length ? '<ul>' + conAlertas.map(function (e) {
        return '<li data-ir="' + esc(e.patente) + '" style="--c:' + COLOR[e.sem] + '">' + chapa(e.patente) + '<div>' + e.alertas.map(function (a) { return '<p>' + esc(a) + '</p>'; }).join('') + '</div></li>';
      }).join('') + '</ul>' : '<p class="sinalertas">Sin alertas por ahora.</p>') + '</aside></div>';

    h += '<p class="nota">La línea de cada camión va desde que levantó ruta hasta ahora; la parte punteada es la proyección al ritmo actual. ' +
      'Línea punteada vertical: fin objetivo. Franja rayada: ventana de apertura (' + ventanaApertura(ahora).join(' a ') + '). ' +
      'Ritmo = clientes visitados por hora desde el inicio de jornada. "Visita hace" se mide desde que este reporte vio el último cambio.</p>';
    $('contenido').innerHTML = h;
    if (popPat) refrescarPopover();
  }

  // ---------- histórico OT ----------
  var HOJA_HIST_URL = 'https://docs.google.com/spreadsheets/d/1kqOCYxMQEhT1TWf43lYzvaN4Oc0m-2GKAhoh2IaPC7k/edit';
  var CLAVE_HIST_CFG = 'ldReporteHistCfg';
  var hcfg = Object.assign({ url: '', dias: 30, ultimo: 0, cerrados: '', foto18: '' }, leerLS(CLAVE_HIST_CFG, {}));
  var hdat = null, herr = '', hleyendo = false, hguardando = false, hmsg = '';
  function guardarCfgHist() { guardarLS(CLAVE_HIST_CFG, hcfg); }
  function fechaISO(d) { d = d || new Date(); return d.getFullYear() + '-' + ('0' + (d.getMonth() + 1)).slice(-2) + '-' + ('0' + d.getDate()).slice(-2); }

  // Arma lo que se guarda: una fila por camión con detalle de clientes y una por cliente.
  function datosHistorico() {
    if (!nb) return null;
    var ahora = new Date(), fecha = fechaISO(ahora), camiones = [], clientes = [];
    nb.cams.forEach(function (cam) {
      var pat = String(cam.patente).toUpperCase(), lista = listaClientes(pat);
      if (!lista.length) return;
      var o = otDeCamion(pat, ahora), dc = ch && ch.data && ch.data[pat];
      camiones.push({ fecha: fecha, patente: pat, chofer: dc ? String(dc.chofer || '').replace(/^\d+\s*-\s*/, '') : '',
        jornada: dc && dc.jornadaLiq ? dc.jornadaLiq.join(', ') : '', estado: cam.estado === 'CERRADA' ? 'Cerrada' : 'Abierta',
        pedidos: o.total, ok: o.ok, fuera: o.fuera, sinhora: o.sinhora, vencido: o.vencido, pend: o.pend, rech: o.rech });
      lista.forEach(function (c) {
        var r = evaluarOT(pat, c, ahora);
        clientes.push({ fecha: fecha, patente: pat, codigo: c.codigo || '', cliente: String(c.cliente).replace(/^\s*\d+\s*-\s*/, ''),
          ventana: r.f.length ? textoVentana(r.f) : r.nota || 'Sin ventana', hora: r.h ? hhmm(r.h.t) : '',
          resultado: TXT_OT[r.st], fuente: r.h ? ({ chess: 'Liquidación Chess', nextbyn: 'Nextbyn', reporte: 'Visto por el reporte' })[r.h.fuente] : '',
          prox: r.h && r.h.prox != null ? Math.round(r.h.prox) : '' });
      });
    });
    return camiones.length ? { camiones: camiones, clientes: clientes } : null;
  }

  // Guarda cada 30 minutos, cuando un camión cierra la jornada y una vez después de las 18:00.
  function quizasGuardar() {
    if (!hcfg.url || !nb || !ch || hguardando || !esHoy()) return;
    var ahora = new Date(), hoyS = fechaISO(ahora);
    var cerrados = nb.cams.filter(function (c) { return c.estado === 'CERRADA'; }).map(function (c) { return c.patente; }).sort().join(',');
    var motivo = '';
    if (Date.now() - hcfg.ultimo > 30 * 6e4) motivo = 'periódico';
    else if (cerrados !== hcfg.cerrados) motivo = 'cierre de jornada';
    else if (ahora.getHours() >= 18 && hcfg.foto18 !== hoyS) motivo = 'cierre del día';
    if (motivo) guardarHistorico();
  }
  function guardarHistorico() {
    var datos = datosHistorico();
    if (!hcfg.url) { hmsg = 'Falta pegar la dirección del script (paso 2).'; pintarHistorico(); return Promise.resolve(); }
    if (!datos) { hmsg = 'Todavía no hay datos de hoy para guardar: tocá Actualizar todo en el Tablero.'; pintarHistorico(); return Promise.resolve(); }
    hguardando = true; pintarHistorico();
    return pedir('guardarHistorico', { url: hcfg.url, datos: datos }).then(function (r) {
      var ahora = new Date();
      hcfg.ultimo = Date.now();
      hcfg.cerrados = nb.cams.filter(function (c) { return c.estado === 'CERRADA'; }).map(function (c) { return c.patente; }).sort().join(',');
      if (ahora.getHours() >= 18) hcfg.foto18 = fechaISO(ahora);
      guardarCfgHist();
      hmsg = 'Guardado a las ' + hhmm(ahora) + ': ' + r.camiones + (r.camiones === 1 ? ' camión' : ' camiones') + ' y ' + r.clientes + (r.clientes === 1 ? ' cliente.' : ' clientes.');
      herr = '';
    }).catch(function (e) {
      hmsg = '';
      herr = String(e.message || e) === 'NOEXT' ? 'Falta la extensión.' : 'No se pudo guardar: ' + (e.message || e);
    }).then(function () { hguardando = false; pintarHistorico(); });
  }

  function abrirHistorico() { if (!hdat && !hleyendo) leerHistorico(); else pintarHistorico(); }
  function leerHistorico() {
    hleyendo = true; pintarHistorico();
    var d = new Date(); d.setDate(d.getDate() - hcfg.dias + 1);
    return pedir('historico', { desde: fechaISO(d) }).then(function (r) {
      hdat = { camiones: filasHist(r.camiones, ['fecha', 'patente', 'chofer', 'pedidos', 'ok', 'fuera', 'sinhora', 'vencido', 'pend', 'rech']),
        clientes: filasHist(r.clientes, ['fecha', 'patente', 'codigo', 'cliente', 'ventana', 'resultado']), at: r.at };
      herr = '';
    }).catch(function (e) { herr = String(e.message || e) === 'NOEXT' ? 'Falta la extensión.' : String(e.message || e); })
      .then(function () { hleyendo = false; pintarHistorico(); });
  }
  function filasHist(csv, campos) {
    return leerCSV(csv || '').slice(1).filter(function (f) { return f[0]; }).map(function (f) {
      var o = {};
      campos.forEach(function (c, i) { o[c] = f[i] == null ? '' : String(f[i]).trim(); });
      var m = /^(\d{1,2})\/(\d{1,2})\/(\d{4})/.exec(o.fecha);
      if (m) o.fecha = m[3] + '-' + ('0' + m[2]).slice(-2) + '-' + ('0' + m[1]).slice(-2);
      o.fecha = o.fecha.slice(0, 10);
      ['pedidos', 'ok', 'fuera', 'sinhora', 'vencido', 'pend', 'rech'].forEach(function (k) { if (k in o) o[k] = +o[k] || 0; });
      return o;
    });
  }

  // Gráfico de barras del OT diario de la flota (SVG).
  function graficoOT(dias) {
    if (!dias.length) return '<p class="h-vacio">Todavía no hay días guardados en este rango.</p>';
    var W = Math.max(640, dias.length * 34), H = 220, pad = { l: 40, r: 10, t: 22, b: 34 };
    var bw = (W - pad.l - pad.r) / dias.length, y = function (v) { return pad.t + (1 - v) * (H - pad.t - pad.b); };
    var g = '<svg viewBox="0 0 ' + W + ' ' + H + '" width="' + W + '" height="' + H + '" class="h-graf" role="img" aria-label="OT diario de la flota">';
    [0, 0.25, 0.5, 0.75, 1].forEach(function (v) {
      g += '<line x1="' + pad.l + '" x2="' + (W - pad.r) + '" y1="' + y(v) + '" y2="' + y(v) + '" class="h-grid"/><text x="' + (pad.l - 6) + '" y="' + (y(v) + 4) + '" class="h-eje" text-anchor="end">' + Math.round(v * 100) + '%</text>';
    });
    dias.forEach(function (d, i) {
      var v = d.pedidos ? d.ok / d.pedidos : 0, x = pad.l + i * bw + bw * 0.18, w = bw * 0.64;
      var cls = v >= 0.9 ? 'b-ok' : v >= 0.75 ? 'b-med' : 'b-mal';
      g += '<rect x="' + x + '" y="' + y(v) + '" width="' + w + '" height="' + (y(0) - y(v)) + '" class="' + cls + '" rx="2"><title>' + d.fecha + ': OT ' + Math.round(v * 100) + '% (' + d.ok + ' de ' + d.pedidos + ' a tiempo, ' + d.camiones + ' camiones)</title></rect>';
      if (dias.length <= 31) g += '<text x="' + (x + w / 2) + '" y="' + (y(v) - 5) + '" class="h-val" text-anchor="middle">' + Math.round(v * 100) + '</text>';
      if (dias.length <= 16 || i % Math.ceil(dias.length / 16) === 0) g += '<text x="' + (x + w / 2) + '" y="' + (H - 12) + '" class="h-eje" text-anchor="middle">' + d.fecha.slice(8, 10) + '/' + d.fecha.slice(5, 7) + '</text>';
    });
    return g + '</svg>';
  }

  function pintarHistorico() {
    var el = $('historico');
    if (!el) return;
    var h = '<div class="h-cab"><div><h2>Histórico de OT</h2><p>Pedidos entregados dentro de su ventana horaria sobre el total de pedidos de cada día. Los datos quedan en la hoja <a href="' + HOJA_HIST_URL + '" target="_blank" rel="noopener">Histórico OT</a>.</p></div>' +
      '<div class="h-ctrl"><label>Período <select id="h-dias">' + [7, 30, 90, 365].map(function (n) { return '<option value="' + n + '"' + (hcfg.dias === n ? ' selected' : '') + '>Últimos ' + n + ' días</option>'; }).join('') + '</select></label>' +
      '<button type="button" id="h-leer"' + (hleyendo ? ' disabled' : '') + '>' + (hleyendo ? 'Leyendo…' : 'Actualizar histórico') + '</button>' +
      '<button type="button" id="h-guardar"' + (hguardando ? ' disabled' : '') + '>' + (hguardando ? 'Guardando…' : 'Guardar el día ahora') + '</button></div></div>';
    if (herr) h += '<div class="err">' + esc(herr) + '</div>';
    if (hmsg) h += '<p class="h-msg">' + esc(hmsg) + '</p>';
    if (!hcfg.url) h += '<div class="h-setup"><h3>Configurar el guardado (una sola vez)</h3><ol>' +
      '<li>Abrí la hoja <a href="' + HOJA_HIST_URL + '" target="_blank" rel="noopener">Histórico OT</a> y entrá a <b>Extensiones → Apps Script</b>.</li>' +
      '<li>Borrá lo que aparece y pegá todo el código del archivo <a href="https://drive.google.com/file/d/1fqx8tlNRBFWFlebCBAclVuUMPtxloKUg/view" target="_blank" rel="noopener">Codigo.gs</a> (está en la misma carpeta de Drive). Guardá con el ícono del disquete.</li>' +
      '<li>Tocá <b>Implementar → Nueva implementación</b>, elegí el tipo <b>Aplicación web</b>, con <b>Ejecutar como: Yo</b> y <b>Quién tiene acceso: Cualquier persona</b>. Autorizá los permisos que pide Google.</li>' +
      '<li>Copiá la <b>URL de la aplicación web</b> (termina en /exec) y pegala acá:</li></ol>' +
      '<div class="h-url"><input id="h-url" placeholder="https://script.google.com/macros/s/…/exec"><button type="button" id="h-url-ok">Guardar dirección</button></div>' +
      '<p class="h-nota">La dirección queda guardada en este Chrome. Cada PC que tenga el reporte abierto guarda los datos del día; si varias lo tienen abierto, queda el último envío. El mismo script actualiza una vez por día la base de clientes desde Chess.</p></div>';
    else h += '<p class="h-estado">Guardado automático activo en este Chrome' + (hcfg.ultimo ? ', último envío a las ' + hhmm(hcfg.ultimo) : '') + '. <button type="button" class="h-link" id="h-url-cambiar">Cambiar dirección del script</button></p>' +
      '<p class="h-nota">Si cambia el código del script (archivo <a href="https://drive.google.com/file/d/1fqx8tlNRBFWFlebCBAclVuUMPtxloKUg/view" target="_blank" rel="noopener">Codigo.gs</a>): pegalo en Apps Script, guardá y tocá <b>Implementar → Administrar implementaciones → lápiz → Versión: Nueva versión → Implementar</b>. Así la dirección no cambia.</p>';

    if (hdat) {
      var porDia = {}, porCam = {}, porCli = {};
      hdat.camiones.forEach(function (r) {
        var d = (porDia[r.fecha] = porDia[r.fecha] || { fecha: r.fecha, pedidos: 0, ok: 0, camiones: 0 });
        d.pedidos += r.pedidos; d.ok += r.ok; d.camiones++;
        var c = (porCam[r.patente] = porCam[r.patente] || { patente: r.patente, chofer: r.chofer, dias: 0, pedidos: 0, ok: 0, fuera: 0, vencido: 0 });
        c.dias++; c.pedidos += r.pedidos; c.ok += r.ok; c.fuera += r.fuera; c.vencido += r.vencido; if (r.chofer) c.chofer = r.chofer;
      });
      hdat.clientes.forEach(function (r) {
        var k = r.codigo || r.cliente;
        var c = (porCli[k] = porCli[k] || { codigo: r.codigo, cliente: r.cliente, ventana: r.ventana, pedidos: 0, ok: 0, fuera: 0 });
        c.pedidos++; if (r.resultado === 'A tiempo') c.ok++; if (r.resultado === 'Fuera de ventana' || r.resultado === 'Ventana vencida') c.fuera++;
        c.ventana = r.ventana || c.ventana;
      });
      var dias = Object.keys(porDia).sort().map(function (k) { return porDia[k]; });
      var tot = dias.reduce(function (a, d) { a.p += d.pedidos; a.o += d.ok; return a; }, { p: 0, o: 0 });
      var ult = dias[dias.length - 1];
      h += '<section class="h-bloque"><div class="h-kpis"><div class="cifra"><b>' + pct(tot.o, tot.p) + '</b><span>OT del período, ' + tot.o + ' de ' + tot.p + ' pedidos</span></div>' +
        (ult ? '<div class="cifra"><b>' + pct(ult.ok, ult.pedidos) + '</b><span>último día guardado (' + ult.fecha.slice(8, 10) + '/' + ult.fecha.slice(5, 7) + ')</span></div>' : '') +
        '<div class="cifra"><b>' + dias.length + '</b><span>días con datos</span></div></div>' +
        '<h3>OT diario de la flota</h3><div class="h-scroll">' + graficoOT(dias) + '</div><p class="h-nota">Verde: 90% o más. Ámbar: de 75% a 89%. Rojo: menos de 75%.</p></section>';
      var cams = Object.keys(porCam).map(function (k) { return porCam[k]; }).sort(function (a, b) { return (a.pedidos ? a.ok / a.pedidos : 0) - (b.pedidos ? b.ok / b.pedidos : 0); });
      h += '<div class="h-dos"><section class="h-bloque"><h3>OT por camión</h3><table class="cli"><thead><tr><th>Camión</th><th>Chofer</th><th class="n">Días</th><th class="n">Pedidos</th><th class="n">Fuera de ventana</th><th class="n">OT</th></tr></thead><tbody>' +
        cams.map(function (c) { return '<tr><td>' + chapa(c.patente) + '</td><td>' + esc(c.chofer) + '</td><td class="n">' + c.dias + '</td><td class="n">' + c.pedidos + '</td><td class="n">' + (c.fuera + c.vencido) + '</td><td class="n"><b>' + pct(c.ok, c.pedidos) + '</b></td></tr>'; }).join('') +
        '</tbody></table></section>';
      var clis = Object.keys(porCli).map(function (k) { return porCli[k]; }).filter(function (c) { return c.fuera; })
        .sort(function (a, b) { return b.fuera - a.fuera || a.cliente.localeCompare(b.cliente); }).slice(0, 20);
      h += '<section class="h-bloque"><h3>Clientes con más entregas fuera de ventana</h3>' + (clis.length ? '<table class="cli"><thead><tr><th>Cliente</th><th>Ventana</th><th class="n">Fuera</th><th class="n">Pedidos</th><th class="n">OT</th></tr></thead><tbody>' +
        clis.map(function (c) { return '<tr><td><b>' + esc(c.codigo ? c.codigo + ' - ' : '') + esc(c.cliente) + '</b></td><td>' + esc(c.ventana) + '</td><td class="n">' + c.fuera + '</td><td class="n">' + c.pedidos + '</td><td class="n">' + pct(c.ok, c.pedidos) + '</td></tr>'; }).join('') +
        '</tbody></table>' : '<p class="h-vacio">Ningún cliente quedó fuera de ventana en este período.</p>') + '</section></div>';
    } else if (!hleyendo && !herr) h += '<p class="h-vacio">Tocá <b>Actualizar histórico</b> para ver los datos guardados.</p>';
    el.innerHTML = h;
  }
  $('historico').addEventListener('click', function (ev) {
    var t = ev.target;
    if (t.id === 'h-leer') leerHistorico();
    else if (t.id === 'h-guardar') guardarHistorico();
    else if (t.id === 'h-url-cambiar') { hcfg.url = ''; guardarCfgHist(); pintarHistorico(); }
    else if (t.id === 'h-url-ok') {
      var u = $('h-url').value.trim();
      if (!/^https:\/\/script\.google\.com\/macros\/s\/[\w-]+\/exec$/.test(u)) { herr = 'La dirección tiene que ser la de la aplicación web y terminar en /exec.'; pintarHistorico(); return; }
      hcfg.url = u; herr = ''; guardarCfgHist(); guardarHistorico();
    }
  });
  $('historico').addEventListener('change', function (ev) {
    if (ev.target.id === 'h-dias') { hcfg.dias = +ev.target.value; guardarCfgHist(); leerHistorico(); }
  });

  // ---------- eventos ----------
  function alternar(p) { abiertos[p] = !abiertos[p]; pintar(); }
  $('b-todo').addEventListener('click', actualizarTodo);
  $('b-nb').addEventListener('click', function () { if (modoApp()) location.hash = '#choferes'; else actualizar('nextbyn'); });
  $('b-ch').addEventListener('click', function () { actualizar('chess'); });
  $('auto').addEventListener('change', function () { programar(); pintarSub(); });
  // ---------- vista previa de prioridad (hover, foco o toque) ----------
  var pop = document.createElement('div');
  pop.className = 'pp';
  pop.setAttribute('role', 'dialog');
  pop.hidden = true;
  document.body.appendChild(pop);
  var popPat = '', popBtn = null, popFijo = false, popCierre = null;
  function abrirPopover(btn, fijo) {
    clearTimeout(popCierre);
    popBtn = btn; popPat = btn.getAttribute('data-prio'); popFijo = !!fijo;
    pop.innerHTML = vistaPrioridad(popPat);
    pop.setAttribute('aria-label', 'Prioridad de pedidos pendientes de ' + popPat);
    pop.hidden = false;
    var r = btn.getBoundingClientRect(), w = pop.offsetWidth, hgt = pop.offsetHeight;
    var x = Math.min(Math.max(8, r.left), window.innerWidth - w - 8);
    var y = r.bottom + 6;
    if (y + hgt > window.innerHeight - 8 && r.top - hgt - 6 > 8) y = r.top - hgt - 6;
    pop.style.left = x + window.scrollX + 'px';
    pop.style.top = y + window.scrollY + 'px';
  }
  function cerrarPopover() { pop.hidden = true; popPat = ''; popBtn = null; popFijo = false; }
  function cerrarLuego() { clearTimeout(popCierre); popCierre = setTimeout(function () { if (!popFijo) cerrarPopover(); }, 180); }
  function refrescarPopover() {
    if (!popPat) return;
    var b = document.querySelector('button.prio[data-prio="' + popPat.replace(/"/g, '') + '"]');
    if (b) abrirPopover(b, popFijo); else cerrarPopover();
  }
  $('contenido').addEventListener('mouseover', function (ev) {
    var b = ev.target.closest && ev.target.closest('button.prio');
    if (b && !popFijo && b !== popBtn) abrirPopover(b, false);
    else if (b) clearTimeout(popCierre);
  });
  $('contenido').addEventListener('mouseout', function (ev) {
    var b = ev.target.closest && ev.target.closest('button.prio');
    if (b && !b.contains(ev.relatedTarget) && !pop.contains(ev.relatedTarget)) cerrarLuego();
  });
  pop.addEventListener('mouseenter', function () { clearTimeout(popCierre); });
  pop.addEventListener('mouseleave', cerrarLuego);
  $('contenido').addEventListener('focusin', function (ev) {
    var b = ev.target.closest && ev.target.closest('button.prio');
    if (b && !popFijo) abrirPopover(b, false);
  });
  $('contenido').addEventListener('focusout', function (ev) {
    var b = ev.target.closest && ev.target.closest('button.prio');
    if (b && !popFijo) cerrarLuego();
  });
  document.addEventListener('keydown', function (ev) { if (ev.key === 'Escape' && popPat) { var b = popBtn; cerrarPopover(); if (b) b.focus(); } });
  document.addEventListener('click', function (ev) {
    if (popPat && !pop.contains(ev.target) && !(ev.target.closest && ev.target.closest('button.prio'))) cerrarPopover();
  });
  window.addEventListener('resize', function () { if (popPat) cerrarPopover(); });

  $('contenido').addEventListener('click', function (ev) {
    var bd = ev.target.closest('button.dem-edit');
    if (bd) {
      ev.stopPropagation();
      var cod = bd.getAttribute('data-dem'), man = bd.getAttribute('data-man') === '1';
      var v = window.prompt('Demora por visita para ' + bd.getAttribute('data-nom') + ' (minutos).\n' +
        (man ? 'Dejalo vacío para volver a la estimación automática.' : 'Ahora es ' + bd.getAttribute('data-min') + ' min. Dejalo vacío para no cambiarla.'), man ? bd.getAttribute('data-min') : '');
      if (v === null) return;
      v = String(v).trim().replace(',', '.');
      if (v === '' && !man) return;
      if (v !== '' && !(+v >= 0 && +v <= 180)) { alert('Poné un número de minutos entre 0 y 180.'); return; }
      LTChoferes.guardarDemora(cod, v === '' ? null : Math.round(+v * 10) / 10).then(null, function (e) { alert('No se pudo guardar: ' + e.message); });
      return;
    }
    var bp = ev.target.closest('button.prio');
    if (bp) {
      ev.stopPropagation();
      // Clic o toque: deja la vista fija (en el celular no hay hover). Otro clic la cierra.
      if (popFijo && popBtn === bp) cerrarPopover(); else abrirPopover(bp, true);
      return;
    }
    var cl = ev.target.closest('tr.cl');
    if (cl) { var k = cl.getAttribute('data-cl'); clientesAbiertos[k] = !clientesAbiertos[k]; pintar(); return; }
    if (ev.target.closest('button.al-tog')) { alAbierto = !alAbierto; guardarLS(CLAVE_AL, alAbierto); pintar(); return; }
    var ir = ev.target.closest('li[data-ir]');
    if (ir) {
      var p0 = ir.getAttribute('data-ir');
      abiertos[p0] = true; pintar();
      var f = document.querySelector('.fila[data-p="' + p0.replace(/"/g, '') + '"]');
      if (f) f.scrollIntoView({ behavior: 'smooth', block: 'start' });
      return;
    }
    var fila = ev.target.closest('.fila');
    if (fila) alternar(fila.getAttribute('data-p'));
  });
  $('contenido').addEventListener('keydown', function (ev) {
    if (ev.target.closest && ev.target.closest('button.prio')) return;
    var fila = ev.target.closest && ev.target.closest('.fila');
    if (fila && (ev.key === 'Enter' || ev.key === ' ')) { ev.preventDefault(); alternar(fila.getAttribute('data-p')); }
  });
  $('l-obj').firstChild.textContent = 'Fin objetivo ' + (sabado() ? '(sábados)' : '(lun a vie)');
  $('obj').value = objetivo(new Date());
  $('sin').value = cfg.sinAvance;
  $('demora').value = cfg.demora;
  $('cd-ll').value = cfg.cdLL ? cfg.cdLL.join(', ') : '';
  $('demora').addEventListener('change', function (e) {
    var v = +e.target.value;
    if (!(v >= 0 && v <= 120)) { e.target.value = cfg.demora; return; }
    cfg.demora = v; guardarLS(CLAVE_CFG, cfg); pintar();
  });
  $('cd-ll').addEventListener('change', function (e) {
    var m = /(-?\d+(?:\.\d+)?)\s*[,;\s]\s*(-?\d+(?:\.\d+)?)/.exec(e.target.value || '');
    if (!e.target.value.trim()) cfg.cdLL = null;
    else if (m && Math.abs(+m[1]) <= 90 && Math.abs(+m[2]) <= 180) cfg.cdLL = [+m[1], +m[2]];
    else { e.target.value = cfg.cdLL ? cfg.cdLL.join(', ') : ''; return; }
    e.target.value = cfg.cdLL ? cfg.cdLL.join(', ') : '';
    guardarLS(CLAVE_CFG, cfg); pintar();
  });
  $('obj').addEventListener('change', function (e) {
    if (!/^\d{1,2}:\d{2}$/.test(e.target.value)) { e.target.value = objetivo(new Date()); return; }
    if (sabado()) cfg.objSab = e.target.value; else cfg.objLV = e.target.value;
    guardarLS(CLAVE_CFG, cfg); pintar();
  });
  $('sin').addEventListener('change', function (e) {
    if (!(+e.target.value > 0)) { e.target.value = cfg.sinAvance; return; }
    cfg.sinAvance = +e.target.value; guardarLS(CLAVE_CFG, cfg); pintar();
  });
  var dias = ['domingo', 'lunes', 'martes', 'miércoles', 'jueves', 'viernes', 'sábado'];
  var meses = ['enero', 'febrero', 'marzo', 'abril', 'mayo', 'junio', 'julio', 'agosto', 'septiembre', 'octubre', 'noviembre', 'diciembre'];
  function pintarDia() {
    var d0 = fechaDe(selDia);
    $('hoy').textContent = 'CD Neuquén, ' + dias[d0.getDay()] + ' ' + d0.getDate() + ' de ' + meses[d0.getMonth()] + (esHoy() ? '' : selDia > fechaISO() ? ' (próximo día de entrega)' : ' (día anterior)');
    $('f-dia').value = selDia;
    $('b-hoy').hidden = esHoy();
    document.body.classList.toggle('otro-dia', !esHoy());
    $('l-obj').firstChild.textContent = 'Fin objetivo ' + (sabado(d0) ? '(sábados)' : '(lun a vie)');
    $('obj').value = objetivo(d0);
  }
  function cambiarDia(d) {
    if (!/^\d{4}-\d{2}-\d{2}$/.test(d || '')) d = fechaISO();
    if (d === selDia) return pintarDia();
    selDia = d;
    guardarLS(CLAVE_DIA, { dia: selDia, en: fechaISO() });
    ch = null; errCh = ''; errNb = '';
    nb = modoApp() ? null : esHoy() ? nbNextbyn : null;
    abiertos = {}; clientesAbiertos = {};
    if (window.LTChoferes && LTChoferes.ponerDia) LTChoferes.ponerDia(selDia);
    pintarDia();
    pintar();
    actualizar('chess');
    if (!modoApp()) actualizar('nextbyn');
  }
  $('f-dia').addEventListener('change', function (e) { cambiarDia(e.target.value); });
  $('b-hoy').addEventListener('click', function () { cambiarDia(fechaISO()); });
  pintarDia();
  setInterval(pintarSub, 1000);
  // Redibuja cada minuto para que la línea de "ahora" avance aunque no haya datos nuevos.
  setInterval(function () { if (nb && location.hash !== '#guia') pintar(); }, 60000);

  // ---------- datos para la pestaña Ver en mapa (mapa.js) ----------
  function datosMapa() {
    if (!nb) return null;
    var ahora = ahoraRef();
    var rutas = analizar(nb.cams, ahora).map(function (e) {
      var pat = String(e.patente).toUpperCase();
      var dc = ch && ch.data && ch.data[pat];
      var lista = listaClientes(pat);
      return {
        pat: pat, vehiculo: e.vehiculo || '', sem: e.sem, txt: e.txt, estado: e.estado,
        chofer: dc ? String(dc.chofer || '').replace(/^\d+\s*-\s*/, '') : '',
        clientes: lista.map(function (c) {
          var r = evaluarOT(pat, c, ahora), v = vt && vt.mapa && c.codigo ? vt.mapa[c.codigo] : null;
          var he = c.est ? horaEntrega(pat, c) : null; // hora de la visita (entregados y rechazados)
          return {
            codigo: c.codigo || '', nombre: String(c.cliente || '').replace(/^\s*\d+\s*-\s*/, ''),
            domicilio: c.domicilio || '', localidad: c.localidad || '',
            est: c.est || '', dev: !!r.dev, ll: v ? v.ll : null, st: r.st, riesgo: r.riesgo || '', pos: r.pos || null,
            ventana: r.f.length ? textoVentana(r.f) : (r.nota || 'Sin ventana'),
            hora: he ? hhmm(he.t) : '', t: he ? +new Date(he.t) : null, eta: r.eta ? hhmm(r.eta) : '',
          };
        }),
      };
    });
    return { rutas: rutas, at: nb.at, chAt: ch ? ch.at : null, vtAt: vt ? vt.at : null, sinVentanas: !vt };
  }
  window.LTReporte = { datosMapa: datosMapa, esc: esc, hhmm: hhmm };

  // ---------- pestañas: Tablero / Ver en mapa / Histórico / Guía instalación extensión ----------
  function mostrarVista() {
    var v = location.hash === '#guia' ? 'guia' : location.hash === '#historico' ? 'historico' : location.hash === '#mapa' ? 'mapa' : location.hash === '#choferes' ? 'choferes' : 'tablero';
    $('main').hidden = v !== 'tablero';
    $('guia').hidden = v !== 'guia';
    $('historico').hidden = v !== 'historico';
    $('mapa').hidden = v !== 'mapa';
    $('choferes').hidden = v !== 'choferes';
    document.body.classList.toggle('ver-guia', v !== 'tablero');
    document.body.classList.toggle('ver-mapa', v === 'mapa');
    ['tablero', 'mapa', 'choferes', 'historico', 'guia'].forEach(function (k) {
      $('tab-' + k).classList.toggle('act', v === k);
      $('tab-' + k).setAttribute('aria-selected', String(v === k));
    });
    if (v === 'historico') abrirHistorico();
    if (window.LTMapa) window.LTMapa.visible(v === 'mapa');
    if (v === 'choferes' && window.LTChoferes) LTChoferes.abrir($('choferes'));
  }
  window.addEventListener('hashchange', function () { mostrarVista(); window.scrollTo(0, 0); });
  mostrarVista();

  $('b-base').addEventListener('click', function () { actualizarBase(true); });
  pintarBase();
  pintar();
  consultarVersion();
  actualizarTodo();
})();
